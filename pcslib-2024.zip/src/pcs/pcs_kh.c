/*pcs_kh object  by Oscar Pablo Di Liscia*/
static t_class *pcs_kh_class;
/*
The pcs_kh object evaluates the Kh inclusion of SCs 

 Input:
 hot inlet: "Kh" symbol to see if the two PCS belongs to the same Kh Complex.
 "Khall" symbol to have all the members of the Kh Complex to which the two PCS belongs.
 cold inlets: the two pointers of the PCS to be compared. Must be
 generated using the prime_form object or any other which outputs a pcs
 pointer.
 The output:
 outlet: 
 For the case of "Kh" , if the two PCS belongs to the same Kh complex,
 a bang is fired, otherwise no action is taken. 
 For the case of "Khall" , if the two PCS belongs to the same Kh complex,
 a succesion of lists with two floats each, being the first one of each couple the cardinal
 number of the Member SC and the second one the Ordinal number. If the
 two PCS does not belongs to the same Kh complex, no action is taken. 
 
*/

typedef struct _pcs_kh{
	t_object  x_obj;
	t_float index;
	PCS* pcs1;
	PCS* pcs2;
	t_outlet *kh_out;
	t_atom kl[2];
} t_pcs_kh;

/*****************pcs_kh DEFUNCS************/
void pcs_kh_any(t_pcs_kh *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_kh_new();
void pcs_kh_setup(void);
void pcs_kh_destroy(t_pcs_kh *x);
void kh_get_pcs1(t_pcs_kh *x, t_symbol *s, t_int argc, t_atom *argv);
void kh_get_pcs2(t_pcs_kh *x, t_symbol *s, t_int argc, t_atom *argv);
/*****************pcs_kh PROTOS*************/
/***********************************************/
void pcs_kh_any(t_pcs_kh *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_int i,j;
	t_int cnt;
	t_symbol *temp;
	PCS *tempcs1, *tempcs2;
	t_int ppcs[3]={0,29,67};
	t_int kindx, kflag;
	t_atom *klist;
	t_int pos, zpos;
	cnt=0;
	
	/*check for input errors*/
	if(x->pcs1->find[0]==EOC || x->pcs2->find[0]==EOC ){
		post("pcs_kh: both or one pcs pointers not received.");
		return;
	}
	if(NombresIguales(x->pcs1,x->pcs2)==true ) {
		post("pcs_kh: Input error, both PCS belongs to the same SC.");
		return;
	}
	if(x->pcs1->ncar == x->pcs2->ncar) {
		post("pcs_kh: Input error, both PCS have the same cardinal number.");
		return;
	}
	if(x->pcs1->ncar > 6 || x->pcs2->ncar > 6 || x->pcs1->ncar <= 3 || x->pcs2->ncar < 3) {
		post("pcs_kh: Input error, out of range cardinal number/s");
		return;
	}
	
	
	/*compute index first*/
	/*the Z issue makes things complicated in cardinal 6 PCS...*/
	if(x->pcs1->ncar == 6 && x->pcs1->nord > 35 ) {
		pos=pcs_table_loc(x->pcs1->ncar,x->pcs1->nord);
		if(tableptr[ZLOC+pos] !=0) {
			zpos=tableptr[ZLOC+pos]-1;
			kindx=ppcs[2]*2 + (tableptr[zpos+1]-1)*2;
		}
		else{
			kindx=(ppcs[x->pcs1->ncar - 4]*2)+(x->pcs1->nord-1)*2;
		}
	}
	else{
		kindx=(ppcs[x->pcs1->ncar - 4]*2)+(x->pcs1->nord-1)*2;
	}
	
	/*Kh mess*/
	if(strcmp(s->s_name, "Kh") == 0){
		for(i=1; i<MKS+1; ++i) {
			if(kdataptr[kindx][i]==0) break;
			if(kdataptr[kindx+1][i]==x->pcs2->nord && kdataptr[kindx][i]==x->pcs2->ncar){
				outlet_bang(x->kh_out);
				break;
			}
		}
	}
	
	
	if(strcmp(s->s_name, "Khall") == 0){
		kflag=0;
		for(i=1; i<MKS+1; ++i) {
			if(kdataptr[kindx][i]==0) break;
			if(kdataptr[kindx+1][i]==x->pcs2->nord && kdataptr[kindx][i]==x->pcs2->ncar){
				kflag=1;
				break;
			}
		}
		if(kflag==1){
			klist=x->kl;
			for(i=1; i<MKS+1; ++i) {
				if(kdataptr[kindx][i]==0) break;
				SETFLOAT(&(klist[0]),(float)kdataptr[kindx][i]);
				SETFLOAT(&(klist[1]),(float)kdataptr[kindx+1][i]);
				outlet_list(x->kh_out, gensym("list"),2,x->kl);
				/*if a member of the complex is cardinal 6 and Z, its Z pair is included as well*/
				if(kdataptr[kindx][i]==6) {
					pos=pcs_table_loc(kdataptr[kindx][i],kdataptr[kindx+1][i]);
					if(tableptr[ZLOC+pos] !=0) {
						zpos=tableptr[ZLOC+pos]-1;
						SETFLOAT(&(klist[0]),(float)tableptr[zpos]);
						SETFLOAT(&(klist[1]),(float)tableptr[zpos+1]);
						outlet_list(x->kh_out, gensym("list"),2,x->kl);
					}
				}
			}
		}
	}
	return;		
}
/******************************************/
void *pcs_kh_new()
{
	t_pcs_kh *x = (t_pcs_kh *)pd_new(pcs_kh_class);
	
	x->pcs1=(PCS*)malloc(sizeof(PCS));
	x->pcs2=(PCS*)malloc(sizeof(PCS));
	x->pcs1->find[0]=EOC;
	x->pcs2->find[0]=EOC;
	
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("kh_get_pcs1"));
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("kh_get_pcs2"));
	x->kh_out=outlet_new(&x->x_obj,0);	
	
	return (void *)x;
}
/******************************************/
void pcs_kh_setup(void) {
	pcs_kh_class = class_new(gensym("pcs_kh"),
		(t_newmethod)pcs_kh_new,
		0, sizeof(t_pcs_kh),
		CLASS_DEFAULT,A_DEFFLOAT,0);
	class_addanything(pcs_kh_class, pcs_kh_any);	
	class_addmethod(pcs_kh_class,(t_method)kh_get_pcs1,gensym("kh_get_pcs1"),A_GIMME,0);
	class_addmethod(pcs_kh_class,(t_method)kh_get_pcs2,gensym("kh_get_pcs2"),A_GIMME,0);
}
/******************************************/
void kh_get_pcs1(t_pcs_kh *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_symbol *temp;
	PCS *tempcs;
	
	if(check_ptr_mess(argc,argv,MPID)==FALSE){
		post("pcs_kh warning: no pointer to pcs received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcs);
	CopiaSet(tempcs,x->pcs1);

	return;
}
/******************************************/
void kh_get_pcs2(t_pcs_kh *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_symbol *temp;
	PCS *tempcs;
	
	if(check_ptr_mess(argc,argv,MPID)==FALSE){
		post("pcs_kh warning: no pointer to pcs received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcs);
	CopiaSet(tempcs,x->pcs2);
	
	return;
}
/******************************************/
void pcs_kh_destroy(t_pcs_kh *x){
	
	if(x->pcs1 != NULL){
		free(x->pcs1);
	}
	if(x->pcs2 != NULL){
		free(x->pcs2);
	}
	return;	
}
/******************************************/
