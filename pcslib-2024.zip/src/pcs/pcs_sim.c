/*pcs_sim object  by Oscar Pablo Di Liscia*/
static t_class *pcs_sim_class;
/*
The pcs_sim object evaluates the similarity degree of two SC according either Forte, 
Morris or Isaacson�s critheria.
Input:
hot inlet: "icvsim"  symbol to select Isaacson's similarity. "r0" "r1" "r2" or "rp" 
symbols to select Forte's similarities. "SIM" or "ASIM" symbols to select Morris's 
similarities. 
The output:
outlet: a float value for the case of Morris's or Isaacson similarities.
For the case of Forte's similarities, is the relation requested is r0,
r1 or r2 and stands, the output is a bang, otherwise, no output is generated.
If the relation requested is rp and stands, the output is a list of the
ordinal name of the SCs shared in common between the two SCs compared.
Otherwise, no output is generated. The cardinal number of the shared sets 
equals the cardinal number of the sets compared minus 1.
*/

typedef struct _pcs_sim{
  t_object  x_obj;
  t_float index;
  PCS* pcs1;
  PCS* pcs2;
  t_outlet *sim_out;
  t_atom ordlist[PCSL];
} t_pcs_sim;

/*****************PCS_SIM DEFUNCS************/
void pcs_sim_any(t_pcs_sim *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_sim_new();
void pcs_sim_setup(void);
void pcs_sim_destroy(t_pcs_sim *x);
void get_pcs1(t_pcs_sim *x, t_symbol *s, t_int argc, t_atom *argv);
void get_pcs2(t_pcs_sim *x, t_symbol *s, t_int argc, t_atom *argv);
/*****************PCS_SIM PROTOS*************/
/***********************************************/
void pcs_sim_any(t_pcs_sim *x, t_symbol *s, t_int argc, t_atom *argv)
{
  t_int i,j;
  t_int cnt, cntdos;
  t_symbol *temp;
  t_int ri1[2], ri2[2];
  t_float result, normfac, idvm;
  t_float idv[6];
  PCS *tempcs1, *tempcs2;
  t_int cardm[3][12];
  t_atom *ordlist;
 

  cnt=0;

  /*check for input errors*/
  if(x->pcs1->find[0]==EOC || x->pcs2->find[0]==EOC ){
    post("pcs_sim: both or one pcs pointers not received");
    return;
  }
  if(NombresIguales(x->pcs1,x->pcs2)==true) {
    /*both PCS belongs to the same SC*/
	  post("pcs_sim: both PCS belongs to the same SC!");
    return;
  }
  if(x->pcs1->ncar > 8 || x->pcs1->ncar < 4 || x->pcs2->ncar > 8 || x->pcs2->ncar < 4 ) {
    post("pcs_sim: cardinals of PCS must be <9 and >3");
    return;
  }
  cnt=0;
  for(i = 0; i < ICVL; i++){
    if(x->pcs1->icvmat[i] == x->pcs2->icvmat[i]) cnt++;
  }
  if(cnt==6) {
    /*PCS are Z related*/
    return;
  }
  /*Forte's similarity relations*/
  if(strcmp(s->s_name, "r0") == 0 || strcmp(s->s_name, "r1") == 0 || strcmp(s->s_name, "r2") == 0 || strcmp(s->s_name, "rp") == 0)
    {
      if(x->pcs1->ncar != x->pcs2->ncar) { /*no pcs of different cardinal comparison allowed by Forte*/
	post("PCS belongs to same SC, not comparable using Forte Relations");
	return;
      }
      if(strcmp(s->s_name, "r0") == 0){
		  if(fr0(x->pcs1->icvmat,x->pcs2->icvmat)==true)
			  outlet_bang(x->sim_out);
		  return;
      }
      /******************************************************************/
      if(strcmp(s->s_name, "r1") == 0){
		  if(fr1(x->pcs1->icvmat,x->pcs2->icvmat)==true)
			  outlet_bang(x->sim_out);
		  return;
      }
      /******************************************************************/
      if(strcmp(s->s_name, "r2") == 0){
		  if(fr2(x->pcs1->icvmat,x->pcs2->icvmat)==true)
			  outlet_bang(x->sim_out);
		  return;
	  }

      if(strcmp(s->s_name, "rp") == 0){
	ordlist=x->ordlist;
	tempcs1=(PCS*)malloc(sizeof(PCS));
	tempcs2=(PCS*)malloc(sizeof(PCS));
	for(i = 0; i < x->pcs1->ncar; i++){
	  cnt=0;
	  for(j = 0; j < x->pcs1->ncar; j++){
	    if(j!=i) {
	      tempcs1->find[cnt]=x->pcs1->fprima[j];
	      tempcs2->find[cnt]=x->pcs2->fprima[j];
	      cnt++;
	    }
	  }
	  tempcs1->find[cnt]=EOC;
	  tempcs2->find[cnt]=EOC;
	  forma_prima(tempcs1, tableptr); 
	  forma_prima(tempcs2, tableptr); 
	  cardm[0][i]=tempcs1->nord;
	  cardm[1][i]=tempcs2->nord;
	}
	cnt=0;
	for(i = 0; i < x->pcs1->ncar; i++){
	   for(j = 0; j < x->pcs1->ncar; j++){
	     if(cardm[0][i]==cardm[1][j]){
	       result=(t_float)cardm[0][i];
	       SETFLOAT(&(ordlist[cnt]),result);
	       cnt++;
	     }
	   }
	}
	if(cnt != 0) {
	   outlet_list (x->sim_out, gensym("list"),cnt,x->ordlist);
	}
	free(tempcs1); free(tempcs2);
	return;
      }
    }/*end Forte*/
  
  if(strcmp(s->s_name, "SIM") == 0){
	  result=sim(x->pcs1->icvmat,x->pcs2->icvmat);
	  outlet_float(x->sim_out,result);
	  return;	
  }
  if(strcmp(s->s_name, "ASIM") == 0){
	  result=asim(x->pcs1->icvmat,x->pcs2->icvmat);
	  outlet_float(x->sim_out,result);
	  return;	
  }
  if(strcmp(s->s_name, "icvsim") == 0){
	  result=icvsim(x->pcs1->icvmat,x->pcs2->icvmat);
	  outlet_float(x->sim_out,result);
	  return;	
  }

  if(strcmp(s->s_name, "Kh") == 0 || strcmp(s->s_name, "Khall") == 0){
	  post("Kh Complexes not anymore supported by pcs_sim, use the pcs_kh object instead");
	  return;	
  }

  return;		
}
/******************************************/
void *pcs_sim_new()
{
  t_pcs_sim *x = (t_pcs_sim *)pd_new(pcs_sim_class);

  x->pcs1=(PCS*)malloc(sizeof(PCS));
  x->pcs2=(PCS*)malloc(sizeof(PCS));
  x->pcs1->find[0]=EOC;
  x->pcs2->find[0]=EOC;
  
  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("get_pcs1"));
  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("get_pcs2"));
  x->sim_out=outlet_new(&x->x_obj,0);	

  return (void *)x;
}
/******************************************/
void pcs_sim_setup(void) {
  pcs_sim_class = class_new(gensym("pcs_sim"),
		       (t_newmethod)pcs_sim_new,
		       0, sizeof(t_pcs_sim),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addanything(pcs_sim_class, pcs_sim_any);	
  class_addmethod(pcs_sim_class,(t_method)get_pcs1,gensym("get_pcs1"),A_GIMME,0);
  class_addmethod(pcs_sim_class,(t_method)get_pcs2,gensym("get_pcs2"),A_GIMME,0);
}
/******************************************/
void get_pcs1(t_pcs_sim *x, t_symbol *s, t_int argc, t_atom *argv)
{
  t_symbol *temp;
  PCS *tempcs;
  
  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("pcs_sim warning: no pointer to pcs received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  CopiaSet(tempcs,x->pcs1);
  return;
}
/******************************************/
void get_pcs2(t_pcs_sim *x, t_symbol *s, t_int argc, t_atom *argv)
{
  t_symbol *temp;
  PCS *tempcs;

  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("pcs_sim warning: no pointer to pcs received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  CopiaSet(tempcs,x->pcs2);
  return;
}
/******************************************/
void pcs_sim_destroy(t_pcs_sim *x){
 
  if(x->pcs1 != NULL){
    free(x->pcs1);
  }
  if(x->pcs2 != NULL){
    free(x->pcs2);
  }
  return;	
}
/******************************************/
