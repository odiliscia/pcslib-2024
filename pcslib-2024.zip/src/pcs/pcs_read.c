/*pcs_read object  by Oscar Pablo Di Liscia*/
static t_class *pcs_read_class;
/*
The pcs_read object expects a pointer to a PCS struct (x->pcs).
The pointer must be generated using the prime_form object or any
other.
The output:
outlet1: original pc of the pcs(floats list)
outlet2: cardinal number(float)
outlet3: ordinal number(float)
outlet4: status (T/I)(symbol)
outlet5: prime form(floats list)
outlet6: interval class vector(floats list)
*/
typedef struct _pcs_read{
  t_object  x_obj;
  t_int no_pf;	          /*ordinal number*/
  t_int nc_pf;	          /*cardinal number*/
  PCS *pcs;		  /*pointer to PCS struct*/
  t_atom pflist[PCSL];    /*prime form*/
  t_atom ivlist[7];       /*interval class vector*/
  t_atom filist[PCSL];    /*individual form(may have pc repeated)*/
  t_atom clist[PCSL];     /*complement list*/
  t_atom tlist[2];     /*IT [0]=T, [1]=I list*/
  t_outlet *nc_out, *no_out, *pf_out, *iv_out, *ti_out, *fi_out, *co_out;
} t_pcs_read;

/*****************PCS_READ DEFUNCS************/
void pcs_read_list(t_pcs_read *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_read_new();
void pcs_read_setup(void);
void pcs_read_destroy(t_pcs_read *x);
/*****************PCS_READ PROTOS*************/
/***********************************************/
void pcs_read_list(t_pcs_read *x, t_symbol *s, t_int argc, t_atom *argv){
  t_int i,j,cp=0,index=0,n;
  float tempf;
  t_atom *pflist, *ivlist, *filist, *clist, *tilist;
  t_symbol *temps, *temp;
  void *tpcs;
  t_int cvec[PCSL];
  PCS *tempcs;
 

  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("pcs_read warning: no pointer to pcs received");
    return;
  }

  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  CopiaSet(tempcs,x->pcs);

  
  if(x->pcs->find[0]==EOC){
    	
    	//outlet_list (x->co_out, gensym("list"),12-x->pcs->ncar,x->clist);
  	//outlet_list (x->iv_out, gensym("list"),ICVL,x->ivlist);
  	//outlet_list (x->pf_out, gensym("list"),x->pcs->ncar,x->pflist);
  	//outlet_list (x->ti_out, gensym("list"),2,x->tlist);
  	//outlet_float(x->no_out,x->no_pf);
  	x->nc_pf=0.;
  	outlet_float(x->nc_out,x->nc_pf);	
  	//outlet_list (x->fi_out, gensym("list"),n,x->filist);
    	
    	post("pcsread: NULL SET");
    return;
  }
  

  pflist=x->pflist;
  ivlist=x->ivlist;
  filist=x->filist;
  clist=x->clist;
  tilist=x->tlist;

  /*pickup data from pcs struct*/
  x->nc_pf=x->pcs->ncar;
  x->no_pf=x->pcs->nord;

  for(i=0; i<x->pcs->ncar; ++i) {
    if(i == PCSL-1) {
      break;
    }
    tempf=(float)x->pcs->fprima[i];
    SETFLOAT(&(pflist[i]),tempf);
  }
  for(i=0; i<PCSL; ++i) {
    if(x->pcs->find[i]==EOC) {
      n=i;
      break;
    }
    tempf=(float)x->pcs->find[i];
    SETFLOAT(&(filist[i]),tempf);
  }
  for(i=0; i<ICVL; ++i) {
    tempf=(float)x->pcs->icvmat[i];
    SETFLOAT(&(ivlist[i]),tempf);
  }
  

  //temps=gensym(x->pcs->Status);
  /*Status field is not anymore a symbol*/
  /*instead, it is a list of two floats*/
  SETFLOAT(&(tilist[0]),(float)x->pcs->T);
  SETFLOAT(&(tilist[1]),(float)x->pcs->I);


  /*find literal complement*/
  index=0;
  for(i=0; i<12; ++i) {
    cp=0; j=0;
    while(x->pcs->find[j] != EOC) {
      if(x->pcs->find[j]==i){
	++cp;
	break;
      }
      j++;
    }
    if(cp==0){
      cvec[index++]=i;
    }
  }
  for(i=0; i<12-x->pcs->ncar; ++i) {
    tempf=(float)cvec[i];
    SETFLOAT(&(clist[i]),tempf);
  }

  /*output data via outlets*/
  outlet_list (x->co_out, gensym("list"),12-x->pcs->ncar,x->clist);
  outlet_list (x->iv_out, gensym("list"),ICVL,x->ivlist);
  outlet_list (x->pf_out, gensym("list"),x->pcs->ncar,x->pflist);
  outlet_list (x->ti_out, gensym("list"),2,x->tlist);
  outlet_float(x->no_out,x->no_pf);
  outlet_float(x->nc_out,x->nc_pf);	
  outlet_list (x->fi_out, gensym("list"),n,x->filist);		
  
  return;		
}
/******************************************/
void *pcs_read_new()
{
  t_pcs_read *x = (t_pcs_read *)pd_new(pcs_read_class);
  x->pcs=NULL;

  if(tableptr==NULL) {
    post("pcs_read: PCS table not allocated!");
    return(NULL);
  }
	
  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;

  x->fi_out=outlet_new(&x->x_obj, &s_float);	
  x->nc_out=outlet_new(&x->x_obj, &s_float);
  x->no_out=outlet_new(&x->x_obj, &s_float);
  x->ti_out=outlet_new(&x->x_obj, &s_symbol);
  x->pf_out=outlet_new(&x->x_obj, &s_float);
  x->iv_out=outlet_new(&x->x_obj, &s_float);
  x->co_out=outlet_new(&x->x_obj, &s_float);

  return (void *)x;
}
/******************************************/
void pcs_read_setup(void) {
  pcs_read_class = class_new(gensym("pcs_read"),
		       (t_newmethod)pcs_read_new,
		       0, sizeof(t_pcs_read),
		       CLASS_DEFAULT,A_DEFFLOAT,0);

  class_addlist(pcs_read_class, pcs_read_list);	
}

/******************************************/
void pcs_read_destroy(t_pcs_read *x){

  if(x->pcs != NULL){
    free(x->pcs);
  }
  return;	
}
/******************************************/
