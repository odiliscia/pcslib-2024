/*pcs_pf object  by Oscar Pablo Di Liscia*/
static t_class *pcs_pf_class;
/*
The pcs_pf object expects a list with pc by its
inlet: 0-11(C to B). -1 is end of position, and -2 is end of chain.
It obtain then the prime form and store all the data into a
PCS struct (x->pcs).
The output is a pointer to that struct. To access the data, a pcs_read
object must be used.
*/
typedef struct _pcs_pf{
  t_object  x_obj;
  PCS *pcs;		  /*pointer to PCS struct*/
  t_outlet  *pcs_out;
} t_pcs_pf;
/*****************PCS_PF DEFUNCS************/
void pcs_pf_any(t_pcs_pf *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_pf_new();
void pcs_pf_setup(void);
void pcs_pf_destroy(t_pcs_pf *x);
/*****************PCS_PF PROTOS*************/
/***********************************************/
void pcs_pf_any(t_pcs_pf *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int i; 
  t_symbol *temp_symbol;
  char pstr[STRLP]; 
  t_symbol *temps;
  t_atom plist[2];
  t_int lastp=0;

  /*pickup a list with pcs*/
  for(i = 0; i < argc; i++){
    temp = atom_getsymbol(&argv[i]);
    if(strcmp(temp->s_name, "float") == 0){
      x->pcs->find[i] =(t_int)atom_getfloat(&argv[i]);
      if(x->pcs->find[i] < 0 && x->pcs->find[i]!=EOP)
	x->pcs->find[i]=abs(x->pcs->find[i]);
      if(x->pcs->find[i] >= 12) 
	x->pcs->find[i]=x->pcs->find[i]%12; /*take modulo-12*/
    }
  }
  if(x->pcs->find[i-1] ==EOP) {
    x->pcs->find[i-1] =EOC;
  }
  else {
    x->pcs->find[i] =EOC;
  }

  if(x->pcs->find[0]==EOC){
    //post("pcs_pf: NULL");
    return;
  }
  

  /*find prime form*/
  forma_prima(x->pcs, tableptr); 
  
  /*convert pointer to PCS struct into symbol*/
  sprintf(pstr, "%p", x->pcs);
  temp_symbol = gensym(pstr);
  temps=gensym(MPID); /*ident*/

  SETSYMBOL(&(plist[0]),temps);
  SETSYMBOL(&(plist[1]),temp_symbol);
  outlet_list (x->pcs_out, gensym("list"),2,plist);


  return;		
}
/******************************************/
void *pcs_pf_new()
{
  t_pcs_pf *x = (t_pcs_pf *)pd_new(pcs_pf_class);
  x->pcs=NULL;

  if(tableptr==NULL) {
    post("pcs_pf: PCS table not allocated!");
    return(NULL);
  }
	
  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;
  
  x->pcs_out=outlet_new(&x->x_obj, &s_list);

  return (void *)x;
}
/******************************************/
void pcs_pf_setup(void) {
  pcs_pf_class = class_new(gensym("pcs_pf"),
		       (t_newmethod)pcs_pf_new,
		       0, sizeof(t_pcs_pf),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addanything(pcs_pf_class, pcs_pf_any);
}
/******************************************/
void pcs_pf_destroy(t_pcs_pf *x){

  if(x->pcs != NULL){
    free(x->pcs);
  }
  return;	
}
/******************************************/
