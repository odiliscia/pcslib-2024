/*pcs_parts object	by Oscar Pablo Di Liscia*/
static t_class *pcs_parts_class;
/*
The pcs_parts object expects a pointer to a PCS struct (x->pcs).
The pointer must be generated using the prime_form object or any
other. The cardinal of the PCS must be 5 or 6.
It find then all the the binary partitions of the PCS.
The output:
outlet1: left pcs part of the partition (floats list)
outlet2: right pcs part of the partition (floats list)
outlet3: a float indicating the kind of partition(0,1,2,3,4,or 12).
*/
typedef struct _pcs_parts{
  t_object	x_obj;
  PCS *pcs; 	  /*pointer to PCS struct*/
  t_atom llist[PCSL];	 /*left part of the partition*/
  t_atom rlist[7];		  /*right part of the partition*/
  t_outlet *l_out, *r_out, *ty_out;
  PART* part;
  t_int from;
  t_int to;
} t_pcs_parts;

/*****************PCS_PARTS DEFUNCS************/
void pcs_parts_any(t_pcs_parts *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_parts_new();
void pcs_parts_setup(void);
void pcs_parts_send_out(t_pcs_parts *x);
void pcs_parts_float(t_pcs_parts *x, t_floatarg f);
void pcs_parts_destroy(t_pcs_parts *x);
/*****************PCS_PARTS PROTOS*************/
/***********************************************/
void pcs_parts_any(t_pcs_parts *x, t_symbol *s, t_int argc, t_atom *argv){

	t_symbol *temp;
	PCS *tempcs;
	
	if(check_ptr_mess(argc,argv,MPID)==TRUE){
		
		temp = atom_getsymbol(&argv[1]);
		/*get the pointer to a PCS struct*/
		sscanf(temp->s_name, "%p", &tempcs);
		CopiaSet(tempcs,x->pcs);


		if(x->pcs->ncar <5 || x->pcs->ncar > 6 ){
			post("pcs_part: cardinal of input pcs must be 5 or 6 only");
			return;
		}
		Particiones(x->pcs,x->part,tableptr);
		x->from=0;
		x->to=x->part->cant;
		pcs_parts_send_out(x);
		return;
	}
	else{
			post("pcs_parts warning: no pointer to pcs received");
			return;
		}
		
		
return; 	
}
/******************************************/
void *pcs_parts_new()
{
  t_pcs_parts *x = (t_pcs_parts *)pd_new(pcs_parts_class);
  x->pcs=NULL;

  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;

  x->part  =(PART*)malloc(sizeof(PART));
  x->from=0;
  x->to=0;

  x->l_out=outlet_new(&x->x_obj, &s_float);
  x->r_out=outlet_new(&x->x_obj, &s_float);
  x->ty_out=outlet_new(&x->x_obj, &s_float);

  return (void *)x;
}
/******************************************/
void pcs_parts_setup(void) {
  pcs_parts_class = class_new(gensym("pcs_parts"),
			   (t_newmethod)pcs_parts_new,
			   0, sizeof(t_pcs_parts),
			   CLASS_DEFAULT,A_DEFFLOAT,0);

  class_addanything(pcs_parts_class, pcs_parts_any);
  class_addfloat(pcs_parts_class, pcs_parts_float);
}
/******************************************/
void pcs_parts_send_out(t_pcs_parts *x) {
t_int i,j;
float tempf;
t_atom *llist, *rlist;

llist=x->llist;
rlist=x->rlist;

for(i = x->from; i < x->to; i++){
	/*output partition type*/
	tempf=(float)x->part->clasif[i]; 
	outlet_float(x->ty_out,tempf);
	/*output right part of the partition*/
	for(j=0; j<PCSL; ++j){
		if(x->part->temp2[i].find[j]==EOP) break;
		tempf=(float)x->part->temp2[i].find[j];
		SETFLOAT(&(rlist[j]),tempf);	   
	}
	outlet_list(x->r_out, gensym("list"),j,x->rlist);
	/*output left part of the partition*/
	for(j=0; j<PCSL; ++j){
		if(x->part->temp1[i].find[j]==EOP) break;
		tempf=(float)x->part->temp1[i].find[j];
		SETFLOAT(&(llist[j]),tempf);	   
	}
	outlet_list (x->l_out, gensym("list"),j,x->llist);
}

return;
}
/******************************************/
void pcs_parts_float(t_pcs_parts *x, t_floatarg f) {

	t_int i=(t_int)f;

	switch (i) {
	case 14:
		x->from=0; x->to=5;
		break;	
	case 23:
		x->from=5; x->to=15;
		break;
	case 15:
		x->from=0; x->to=6;
		break;
	case 24:
		x->from=6; x->to=21;
		break;
	case 33:
		x->from=21; x->to=31;
		break;
	case 0:
		x->from=0; x->to=0;
		break;
	} 
	
	return;
}
/******************************************/
void pcs_parts_destroy(t_pcs_parts *x){

  if(x->pcs != NULL){
	free(x->pcs);
  }
  free(x->part);
  return;	
}
/******************************************/
