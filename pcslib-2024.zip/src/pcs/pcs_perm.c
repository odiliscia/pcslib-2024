/*pcs_perm object  by Oscar Pablo Di Liscia*/
static t_class *pcs_perm_class;
/*
The pcs_perm object expects a pointer to a PCS struct (x->pcs) in
its rightmost inlet and calculates all its permutation which are
stored and eventually sent in lexicographical order. The pointer must be generated 
using the prime_form object or any other.
The repetitions of Pitch-classes and different positions, if any, will not be taken
in account. So, for example, a PCS stored as: 0 1 -1 0 11 -1 5 will be considered
as: 0 1 11 5

  Any message in its leftmost inlet will cause the output.
  
	The output:
  
	outlet1: if the size of the set is <=7, any message will produce a series of float lists, 
	being each one of the different permutations of the PCS delivered in lexicographycal order.
	
	A message "get n" being "n" the number of permutation will cause the output of a list with the 
	permutation n only (permutations are numbered starting with "0" which is the original order). 
	This will work with PCS of size > 7.
	
	outlet2: the number of permutations(float). Will be (n!), n being the size of the PCS.
	If this number is used to feed a random generator, the output of this one can be used
	to generate a "get n" message (n being the number of permutation requested).

*/
typedef struct _pcs_perm{
	t_object  x_obj;
	t_int np;	      /*number of different permutations*/
	t_int n;		  /*size of the PCS (without repetitions and/or spaces)*/
	PCS *pcs;		  /*pointer to PCS struct*/
	t_int *pl;        /*array for storing the permutations*/
	t_outlet *perm_out, *np_out;
} t_pcs_perm;

/*****************pcs_perm DEFUNCS************/
void pcs_perm_any(t_pcs_perm *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_perm_new();
void pcs_perm_setup(void);
void pcs_perm_get_pcs(t_pcs_perm *x, t_symbol *s, t_int argc, t_atom *argv);
void pcs_perm_compute_perm(t_pcs_perm *x);
void pcs_perm_destroy(t_pcs_perm *x);
/*****************pcs_perm PROTOS*************/
/***********************************************/
void pcs_perm_any(t_pcs_perm *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_atom perm_list[12];
	t_int i,j, index=0;
	float aux;
	t_symbol *temp; 
	
	if(x->pcs->find[0]==EOC) {
		post("pcs_perm: no PCS pointer received");
		return;
	}
	
	/*the "get n" message*/
	if(strcmp(s->s_name, "get") == 0) {  
		if(argc < 1) {
			post("pcs_perm: you need to indicate the number of permutation requested");
			return;
		}
		temp = atom_getsymbol(&argv[0]);
		if(strcmp(temp->s_name, "float") == 0){
			index= (t_int)atom_getfloat(&argv[0]);
		}
		if(index < 0 || (t_int)index > x->np-1 ) {
			post("pcs_perm: number of permutation out of range!");
			return;
		}
		
		if(x->n <=7) {
			index*=x->n;
			for(j=0; j < x->n; ++j) {
				aux=(float)x->pl[index+j];
				SETFLOAT(&(perm_list[j]),aux); 
			}
		}
		else{
			get_permutation(x->pl, x->np, x->n, index);
			for(j=0; j < x->n; ++j) {
				aux=(float)x->pl[x->n+j];
				SETFLOAT(&(perm_list[j]),aux); 
			}
		}
		outlet_list(x->perm_out, gensym("list"),x->n,perm_list);
		return;
	}
	
	/*send all the permutations only if the set size is <=7 */
	if(x->n <=7) {
		for(i=0; i<x->np; ++i) {
			for(j=0; j < x->n; ++j) {
				aux=(float)x->pl[index+j];
				SETFLOAT(&(perm_list[j]),aux); 
			}
			index+=x->n;
			outlet_list(x->perm_out, gensym("list"),x->n,perm_list);
		}
	}
	else {
		post("pcs_perm: any message is only accepted when the PCS size is < 8!");
	}
	
	return;		
}
/******************************************/
void *pcs_perm_new()
{
	t_pcs_perm *x = (t_pcs_perm *)pd_new(pcs_perm_class);
	x->pcs=NULL;
	
	x->pcs=(PCS*)malloc(sizeof(PCS));
	x->pcs->find[0]=EOC;
	
	x->pl=(t_int*)malloc(sizeof(t_int)*PCSL);
	x->n=0;
	x->np=0;
	
	x->perm_out=outlet_new(&x->x_obj, &s_float);	
	x->np_out=outlet_new(&x->x_obj, &s_float);
	
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("pcs_perm_get_pcs"));
	
	return (void *)x;
}
/******************************************/
void pcs_perm_setup(void) {
	pcs_perm_class = class_new(gensym("pcs_perm"),
		(t_newmethod)pcs_perm_new,
		0, sizeof(t_pcs_perm),
		CLASS_DEFAULT,A_DEFFLOAT,0);
	
	class_addanything(pcs_perm_class, pcs_perm_any);
	class_addmethod(pcs_perm_class,(t_method)pcs_perm_get_pcs,gensym("pcs_perm_get_pcs"),A_GIMME,0);
	
}

/******************************************/
void pcs_perm_get_pcs(t_pcs_perm *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_symbol *temp;
	PCS *tempcs;

	if(check_ptr_mess(argc,argv,MPID)==FALSE){
		post("pcs_perm warning: no pointer to pcs received");
		return;
	}
	
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcs);
	CopiaSet(tempcs,x->pcs);
	if(x->pcs->ncar < 3) {
		post("pcs_perm: PCS must be of cardinal > 3");
		x->pcs->find[0]=EOC;
		return;
	}	
	pcs_perm_compute_perm(x);
	
	return;
}
/******************************************/
void pcs_perm_compute_perm(t_pcs_perm *x)
{
	t_int dummy[PCSL];
	
	x->n=0;
	x->np=0;
	x->n=no_rep(x->pcs,x->pl);
	x->np=factorial(x->n);
	
	/*if the size of the set is < 8 its permutations are previously computed*/
	if(x->n < 8) {
		x->pl=(t_int*)realloc(x->pl,x->np*x->n*sizeof(t_int));
		permutations(x->pl,x->np,x->n);
	}
	/*if the size of the set is >= 8 its permutations are NOT previously computed and
	a specific number of permutation must be requested
	*/
	else {
		/*allocate only space for the set and for just one permutation*/
		x->pl=(t_int*)realloc(x->pl,2*x->n*sizeof(t_int));
	}
	outlet_float(x->np_out,(float)x->np);
	return;
}
/******************************************/
void pcs_perm_destroy(t_pcs_perm *x){
	
	if(x->pcs != NULL){
		free(x->pcs);
	}
	
	if(x->pl != NULL){
		free(x->pl);
	}
	
	return;	
}
/******************************************/
