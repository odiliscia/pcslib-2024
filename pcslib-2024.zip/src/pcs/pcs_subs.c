/*pcs_subs object  by Oscar Pablo Di Liscia*/
static t_class *pcs_subs_class;
/*
The pcs_subs object expects a PCS pointer in its hot inlet
and a float(n) in its cold inlet. n must be in the range of 3 to 7.
It obtain then all the subsets of cardinal n of the PCS.
The output is a series of pointers to the struct of the PCSs. To access 
the data, a pcs_read object must be used.
*/
typedef struct _pcs_subs{
  t_object  x_obj;
  PCS *pcs;		  /*pointer to PCS struct*/
  t_float n;
  t_int a;	/*the "a" flag=true if the adjacent subsets are required and false if not*/
  t_outlet  *pcs_out;
  t_outlet *ns_out;
} t_pcs_subs;
/*****************PCS_SUBS DEFUNCS************/
void pcs_subs_any(t_pcs_subs *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_subs_new();
void pcs_subs_setup(void);
void pcs_subs_set_n(t_pcs_subs *x, t_floatarg f);
void pcs_subs_destroy(t_pcs_subs *x);
/*****************PCS_SUBS PROTOS*************/
/***********************************************/
void pcs_subs_any(t_pcs_subs *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int i,h,j,s_n,err; 
  t_symbol *temp_symbol;
  char pstr[STRLP]; 
  t_symbol *temps;
  t_atom plist[2];
  PCS *pcsbuf=NULL;
  PCS *tpcsbuf=NULL;
  PCS tempcs;
  PCS *tempcs2;
  t_int npcs[7]={12,29,38,50,38,29,12};


  if(strcmp(s->s_name, "ADJ")==0) {
	  x->a=true;
	  return;
  }
 
  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("pcs_subs warning: no pointer to PCS struct received");
    return;
  }
  
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs2);
  CopiaSet(tempcs2,x->pcs);



  /*check for input errors*/
  if(x->pcs->ncar >9 || x->pcs->ncar <4) {
    post("pcs_subs: cardinal of input set must be >3 and <10");
    return;
  }
  if(x->n >= (float)x->pcs->ncar || x->n <3.) {
    post("pcs_subs: cardinal of subsets set must be < than cardinal of set");
    return;
  }

    
  else {
	  if(x->a==false) {
		  s_n=get_n_subsets(x->pcs->ncar,(t_int)x->n);
		  pcsbuf=(PCS*)malloc(sizeof(PCS)*s_n);
		  tpcsbuf=(PCS*)malloc(sizeof(PCS)*s_n);
		  err=Subsets(x->pcs,(t_int)x->n,tpcsbuf,tableptr);
		  if(err==0) {
			  j=0;
			  /*sort by ordinal number*/
			  for(i=1; i<=npcs[(t_int)(x->n-3.)]; i++){ 
				  for(h=0; h < s_n; h++){
					  if(tpcsbuf[h].nord==i) {
						  pcsbuf[j++]=tpcsbuf[h];
					  } 
				  }
			  } 
		  }
		  else{
			  free(pcsbuf);
			  free(tpcsbuf);
			  post("pcs_subs failed");
			  return;
		  }
	  }
	  else {
		  x->a=false;	
		  s_n=(x->pcs->ncar-(t_int)x->n) + 1;
		  pcsbuf=(PCS*)malloc(sizeof(PCS)*s_n);
		  for(i=0; i<s_n; ++i) {
			  for(h=0; h<x->n; ++h) {
				  tempcs.find[h]=x->pcs->find[h+i];	
			  }
			  tempcs.find[h]=EOC;
			  forma_prima(&tempcs, tableptr);
			  CopiaSet(&tempcs,&pcsbuf[i]);
		  }
	  }
  }
  /*send the number of subsets*/
  outlet_float(x->ns_out, (t_float)s_n);
  /*send a series of pointers*/
  for(i=0; i < s_n; i++) {
    /*convert pointer to PCS struct into symbol*/
    sprintf(pstr, "%p", &pcsbuf[i]);
    temp_symbol = gensym(pstr);
    temps=gensym(MPID); 
    SETSYMBOL(&(plist[0]),temps);
    SETSYMBOL(&(plist[1]),temp_symbol);
    outlet_list (x->pcs_out, gensym("list"),2,plist);
  }
  free(pcsbuf);
  if(tpcsbuf != NULL) {
	free(tpcsbuf);
  }
  return;		
}
/******************************************/
void *pcs_subs_new()
{
  t_pcs_subs *x = (t_pcs_subs *)pd_new(pcs_subs_class);
  x->pcs=NULL;


  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;
  x->n=3.;/*default smallest value for n*/
  x->a=false; /*all subsets are required*/
  
  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("float"),gensym("set_n"));
  x->pcs_out=outlet_new(&x->x_obj, &s_list);
  x->ns_out=outlet_new(&x->x_obj, &s_float);

  return (void *)x;
}
/******************************************/
void pcs_subs_setup(void) {
  pcs_subs_class = class_new(gensym("pcs_subs"),
		       (t_newmethod)pcs_subs_new,
		       0, sizeof(t_pcs_subs),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addanything(pcs_subs_class, pcs_subs_any);
  class_addmethod(pcs_subs_class,(t_method)pcs_subs_set_n,gensym("set_n"),A_DEFFLOAT,0);
}
/******************************************/
void pcs_subs_set_n(t_pcs_subs *x, t_floatarg f) {
  x->n=f;
  if(x->n > 8.) x->n=8.;
  if(x->n < 3.) x->n=3.;
  return;
}
/******************************************/
void pcs_subs_destroy(t_pcs_subs *x){

  if(x->pcs != NULL){
    free(x->pcs);
  }
  return;	
}
/******************************************/
