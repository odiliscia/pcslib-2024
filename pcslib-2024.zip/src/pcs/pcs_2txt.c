/*pcs_2txt object  by Oscar Pablo Di Liscia*/
static t_class *pcs_2txt_class;
/*
The pcs_2txt object expects a pointer to a PCS struct.
The pointer must be generated using one of the pcs_ objects.
This object has no output, only post to the pd prompt a
"clean" i.e., not raw, version of the PCS data.
*/
typedef struct _pcs_2txt{
  t_object  x_obj;
  PCS *pcs;   /*pointer to a CM struct*/
  t_outlet  *strout;
  t_int sym;
} t_pcs_2txt;

/*****************PCS_2TXT DEFUNCS************/
void pcs_2txt_list(t_pcs_2txt *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_2txt_new(t_symbol *s, t_int argc, t_atom *argv);
void pcs_2txt_setup(void);
void sym_out(t_pcs_2txt *x, char *str);
void pcs_2txt_destroy(t_pcs_2txt *x);
/*****************PCS_2TXT PROTOS*************/
/***********************************************/
void pcs_2txt_list(t_pcs_2txt *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  char *str, *aux;
  PCS *tempcs;

  aux=(char*)malloc(sizeof(char)*PCSL);
  str=(char*)malloc(sizeof(char)*PCSL*STRLP);
  
  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("pcs_2txt warning: no pointer to PCS received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  CopiaSet(tempcs,x->pcs);

  print_pcs(x->pcs,str);
  /*choose output type (post to prompt or output symbol)*/
  if(x->sym==false) {
	  post("%s",str);
  }
  else {
	*str=0;
	*aux=0;
	if(x->pcs->ncar >=1) { 
		strcat(str, "PCS:       ");
		Pset(x->pcs, aux);
		strcat(str,aux);
		sym_out(x,str);
		
		*str=0; *aux=0;
		strcat(str, "NAME:      ");
		Pname(x->pcs,aux);
		strcat(str,aux);
		sym_out(x,str);

		*str=0;
		strcat(str, "PRIME FORM:");
		Pfp(x->pcs,aux);
		strcat(str,aux);
		sym_out(x,str);
		
		*str=0;
		strcat(str, "TTO:       ");
		Pstat(x->pcs,aux);
		strcat(str,aux);
		sym_out(x,str);
		
		*str=0;
		strcat(str, "ICV:       ");
		Picv(x->pcs,aux);
		strcat(str,aux);
		sym_out(x,str);
	}
	else {
		*str=0;
		strcat(str, "NULL SET");
		sym_out(x,str);
	}


  }

  free(str);free(aux);
  return;		
}
/******************************************/
void sym_out(t_pcs_2txt *x, char *str)
{
	t_symbol *temp_symbol;
	t_atom any[1];
	
	temp_symbol = gensym(str);
	SETSYMBOL(&any[0],temp_symbol);
	outlet_list (x->strout, gensym("list"),1,any);
return;	
}
/******************************************/
void *pcs_2txt_new(t_symbol *s, t_int argc, t_atom *argv)
{
	t_symbol *temp;
	t_pcs_2txt *x = (t_pcs_2txt *)pd_new(pcs_2txt_class);
	x->pcs=NULL;
	
	if(argc > 0) {
		temp = atom_getsymbol(&argv[0]);
		if(strcmp(temp->s_name, "symbol") == 0)
			x->sym=true;
	}
	else{
		x->sym=false;
	}
	
	x->pcs=(PCS*)malloc(sizeof(PCS));
	x->pcs->find[0]=EOC;
	x->strout=outlet_new(&x->x_obj, &s_list);
	return (void *)x;
}
/******************************************/
void pcs_2txt_setup(void) {
  pcs_2txt_class = class_new(gensym("pcs_2txt"),
		       (t_newmethod)pcs_2txt_new,
		       0, sizeof(t_pcs_2txt),
		       CLASS_DEFAULT,A_GIMME,0);

  class_addlist(pcs_2txt_class, pcs_2txt_list);	
}

/******************************************/
void pcs_2txt_destroy(t_pcs_2txt *x){

  if(x->pcs != NULL){
    free(x->pcs);
  }
  return;	
}
/******************************************/
