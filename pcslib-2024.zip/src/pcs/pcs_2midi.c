/*pcs_2midi object  by Oscar Pablo Di Liscia*/

static t_class *pcs_2midi_class;
/*

The pcs_2midi object computes a list of arguments to be further
used to play a PCS through MIDI.

The pcs_2midi object expects a pointer to a PCS struct
and three arguments (dur, pitch offset, velocity).
The pointer must be generated using one of the pcs_ objects.
Each time it receives a bang message at its left inlet it
outputs four arguments with the MIDI data of
tha PC to be played. This data is likely to be used by the 
'makenote' and 'noteout' objects in order to have the note played.

Input (from right to left):

	-5th inlet (rightmost) a PCS structure pointer.

	-4th inlet: a float list containing the velocity values (0 to 127) for
  each one of the PC of the Set. If the list is not delivered, the object
  uses a default value of 64 for all the notes.
  
	-3rd inlet: a float list containing pitch offset values  for
  each one of the PC of the Set. I.e., a value of 60 will keep
  the PC in the central octave, etc. If the list is not delivered, the object
  uses a default value of 60 for all the notes.

	-2nd inlet: a float list containing duration values  for
  each one of the PCs of the Set in milliseconds. If the list is not delivered, the object
  uses a default value of 500 msecs. for all the notes.

  The lenght of the lists required at the inlets 2, 3 and 4 need not match the
  number of PCs of the set neither their respective lenghts. If there is just one value, 
  this value will be used in all the PCs in the set. If there are less values than PCs, 
  those are read until the last one is reach and then this one is repeated 
  as needed. If there are more values than PCs, the exceeding values are not 
  taken in account.

	-1st inlet (leftmost): 
		  -A series of bangs to output the MIDI
		data corresponding to each one of the PCs of the Set.
		Ideally there should be as many bangs as PCs are in the
		set, but this is not neccesarly required.
		If the final PC of the Set was reach and a new bang is
		received, it is ignored until a REWIND message is received.
		
		  -A REWIND n(float) message will cause that the PCs list will start
		  from the position n (0 being the first of the list). 

Output:

  -outlets 4 to 1 (4 is leftmost): a list of four floats each one being 
			4-The order of the PC (0 for the first, 1 for the second, and so on...)
			Handy to check whether all the PC os a Set were played.
			3-The MIDI note of the PC (0-127): this will be= pc[n]+offset
			2-The Velocity Value of the PC (0-127)
			1-The duration of the note in milliseconds.
	Note that the output order is always from right to left
*/

typedef struct _pcs_2midi{
	t_object  x_obj;
	
	PCS *pcs;   /*pointer to a CM struct*/
	float pcsvec[PCSL];
	t_int pcsp, pcsn;
	float vel[PCSL];
	t_int velp, veln;
	float off[PCSL];
	t_int offp, offn;
	float dur[PCSL];
	t_int durp, durn;	
	
	t_outlet *ord_out;
	t_outlet *pit_out;
	t_outlet *vel_out;
	t_outlet *dur_out;

} t_pcs_2midi;

/*****************pcs_2midi DEFUNCS************/
void pcs_2midi_PCS(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv);
void pcs_2midi_VEL(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv);
void pcs_2midi_OFF(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv);
void pcs_2midi_DUR(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv);
void pcs_2midi_any(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv);

void pcs_2midi_reset(t_pcs_2midi *x, t_int n);

void *pcs_2midi_new();
void pcs_2midi_setup(void);
void pcs_2midi_destroy(t_pcs_2midi *x);
/*****************pcs_2midi PROTOS*************/
/***********************************************/
void pcs_2midi_any(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv){

float ord, pc;
float n;
t_symbol *temp;

	if(strcmp(s->s_name, "bang") == 0 ) {

		if(x->pcs->find[0]==EOC) {
			post("pcs_2midi warning: no PCS pointer received");
			return;
		}

		if(x->pcsp == x->pcsn) {
			post("pcs_2midi warning: end of pcs reach, no action taken");
			return;
		}
		
		/*set default values for velocity, duration and offset*/
		if(x->veln==0) {
			x->veln=1;
			x->velp=0;
			x->vel[0]=64;
		}
		if(x->durn==0) {
			x->durn=1;
			x->durp=0;
			x->dur[0]=500;
		}
		if(x->offn==0) {
			x->offn=1;
			x->offp=0;
			x->off[0]=60;
		}


		ord=x->pcsp;
		x->pcsp=(x->pcsp < x->pcsn? ++x->pcsp : x->pcsp);
		
		x->offp=(x->offp < x->offn? ++x->offp : x->offp);
		pc= (float)x->off[x->offp-1] + (float)x->pcsvec[x->pcsp-1];
		
	
		x->velp=(x->velp < x->veln? ++x->velp : x->velp);
		x->durp=(x->durp < x->durn? ++x->durp : x->durp);

		outlet_float(x->dur_out, x->dur[x->durp-1]);
		outlet_float(x->vel_out, x->vel[x->velp-1]);
		outlet_float(x->pit_out, pc);
		outlet_float(x->ord_out, ord);

		return;
	}
	
	if(strcmp(s->s_name, "REWIND") == 0 ) { 
		
		if(argc < 1) {
			pcs_2midi_reset(x,0);
			return;
		}
		
		temp = atom_getsymbol(&argv[0]);
		if(strcmp(temp->s_name, "float") == 0) {
			n= atom_getfloat(&argv[0]);
		}
		pcs_2midi_reset(x,(t_int)n);

		return;
		}
	
	

	return;

}
/***********************************************/
void pcs_2midi_PCS(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv){
	t_symbol *temp;
	t_int i, pointer=0;
	PCS *tempcs;
	
	if(check_ptr_mess(argc,argv,MPID)==FALSE){
		post("pcs_2midi warning: no pointer to PCS received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcs);
	CopiaSet(tempcs, x->pcs);

	pcs_2midi_reset(x,0);
	
	/*take out possible EOC and EOPs and count PCs*/
	for(i=0; i<PCSL; ++i) {
		if(x->pcs->find[i] !=EOP && x->pcs->find[i] != EOC) {
			x->pcsvec[pointer]=(float)x->pcs->find[i];
			pointer++;
		}
		if(x->pcs->find[i] ==EOC)
			break;
	}
	x->pcsn=pointer;

  return;		
}
/******************************************/
void pcs_2midi_VEL(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv){
	
	t_symbol *temp;
	t_int i;
	
	for(i = 0; i < argc; i++){
		temp = atom_getsymbol(&argv[i]);
		if(strcmp(temp->s_name, "float") == 0){
			x->vel[i] =atom_getfloat(&argv[i]);
		}
		if(x->vel[i] > 127. ) {
			post("pcs_2midi: warning, too large velocity value (%f), truncated to 127", x->vel[i]);
			x->vel[i]= 127;
		}
		if(x->vel[i] < 0. ) {
			post("pcs_2midi: warning, too small velocity value (%f), substituted by one", x->vel[i]);
			x->vel[i]= 1;
		}	
	}
	
	pcs_2midi_reset(x,0); //we must reset all the pointers
	x->veln=i;

	return;		
}
/******************************************/
void pcs_2midi_OFF(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv){
	t_symbol *temp;
	
	t_int i;
	
	for(i = 0; i < argc; i++){
		temp = atom_getsymbol(&argv[i]);
		if(strcmp(temp->s_name, "float") == 0){
			x->off[i] =atom_getfloat(&argv[i]);
		}
		if(x->off[i] > 127. ) {
			post("pcs_2midi: warning, too large pitch offset value (%f), truncated to 127", x->off[i]);
			x->off[i]= 127.;
		}
		if(x->off[i] < 0. ) {
			post("pcs_2midi: warning, too small pitch offset (%f), zero substituted", x->off[i]);
			x->off[i]= 0.;
		}	
	}
	
	pcs_2midi_reset(x,0); //we must reset all the pointers
	x->offn=i;

	return;		
}
/******************************************/
void pcs_2midi_DUR(t_pcs_2midi *x, t_symbol *s, t_int argc, t_atom *argv){
	t_symbol *temp;
	
	t_int i;
	
	for(i = 0; i < argc; i++){
		temp = atom_getsymbol(&argv[i]);
		if(strcmp(temp->s_name, "float") == 0){
			x->dur[i] = atom_getfloat(&argv[i]);
		}
		if(x->dur[i] < 0. ) {
			post("pcs_2midi: warning, negative duration values not allowed (%f), taking absolute value", x->dur[i]);
			x->dur[i]=fabs(x->dur[i]);
		}	
	}
	
	pcs_2midi_reset(x,0); //we must reset all the pointers
	x->durn=i;

	return;		
}
/******************************************/
void *pcs_2midi_new()
{
  t_pcs_2midi *x = (t_pcs_2midi *)pd_new(pcs_2midi_class);
  
  x->pcs=NULL;
  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;

  x->pcsn=x->veln=x->offn=x->durn=0;
  pcs_2midi_reset(x,0);

  x->ord_out=outlet_new(&x->x_obj, &s_float);
  x->pit_out=outlet_new(&x->x_obj, &s_float);
  x->vel_out=outlet_new(&x->x_obj, &s_float);
  x->dur_out=outlet_new(&x->x_obj, &s_float);

  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("float"),gensym("pcs_2midi_DUR"));
  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("float"),gensym("pcs_2midi_OFF"));
  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("float"),gensym("pcs_2midi_VEL"));
  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("pcs_2midi_PCS"));
  

  return (void *)x;
}
/******************************************/
void pcs_2midi_setup(void) {
	pcs_2midi_class = class_new(gensym("pcs_2midi"),
		(t_newmethod)pcs_2midi_new,
		0, sizeof(t_pcs_2midi),
		CLASS_DEFAULT,A_DEFFLOAT,0);
	
	class_addanything(pcs_2midi_class, pcs_2midi_any);

	class_addmethod(pcs_2midi_class,(t_method)pcs_2midi_DUR,gensym("pcs_2midi_DUR"),A_GIMME,0);
	class_addmethod(pcs_2midi_class,(t_method)pcs_2midi_OFF,gensym("pcs_2midi_OFF"),A_GIMME,0);
	class_addmethod(pcs_2midi_class,(t_method)pcs_2midi_VEL,gensym("pcs_2midi_VEL"),A_GIMME,0);
	
	class_addmethod(pcs_2midi_class,(t_method)pcs_2midi_PCS,gensym("pcs_2midi_PCS"),A_GIMME,0);
return;	
}
/******************************************/
void pcs_2midi_reset(t_pcs_2midi *x, t_int n)
{

	if(n < 0) n=0;

	if(n==0) {
		x->pcsp=x->offp=x->durp=x->velp=0;
		return;
	}

	x->pcsp= n < x->pcsn? n: x->pcsn-1; 
	x->velp= n < x->veln? n: x->veln-1; 
	x->offp= n < x->offn? n: x->offn-1;
	x->durp= n < x->durn? n: x->durn-1; 
	
return;
}
/******************************************/
void pcs_2midi_destroy(t_pcs_2midi *x){

  if(x->pcs != NULL){
    free(x->pcs);
  }
  return;	
}
/******************************************/
