/*pcs_sim2 object  by Oscar Pablo Di Liscia*/
static t_class *pcs_sim2_class;
/*
The pcs_sim2 object evaluates the similarity degree of two or more PCS according to several criteria.

Input:

  Rightmost inlet: a series of PCS to be mutually compared(at least must be two). The PCS
  are accumulated and mutually compared until a "reset" message is sent via the leftmost inlet. 

  Leftmost inlet: there are several possibilities of messages that can be grouped into three types:

  1-The "reset" message clears the list of PCS stored, if any.

  2-Any of these symbols will cause the output of the result of the following similarities:
    -"r0" "r1" "r2" or "rp" symbols:  Forte's similarities. (only for different SC of the same 
	cardinality which must be >3 and <7).
	-"ICVSIM"  symbol: Isaacson's similarity. (no constraints)
	-"SIM" or "ASIM" symbols: Morris's similarities. (no constraints)
	-"OI" symbol: Babbitt order inversions. (only for different permutations of the same PCS)
	-"DIS" symbol: Morris's Displacement measure.(only for different permutations of the same PCS)
	-"SCAT" symbol: Morris's Scattering measure.(only for different permutations of the same PCS)
	-"CC" symbol: Correlation coefficient.(only for different permutations of the same PCS)
	-"OPSC"symbol, w float: Ordered PCS Similarity Coefficient. Experimentally designed by Pablo Di Liscia.(no constraints,
	 but note that this measurement weight both, the common pitch-classes shared and the similarity 
	 in adjacent PCS, is specially suited for ORDERED PCS). This measuring varies from 0(minimal similarity)
	 to 1(maximal similarity). w is a weighting coefficient between Pitch Similarity and Intervalic Similarity.
	 w may vary between 0 and 1. w=1 takes in account Intervalic Similarity only, whilst w=0 takes 
	 in account Pitch similarity only, w=0.5 weights both equally, and so on.

  3-The "write" message direct the output of the comparison to a raw text file.
This message must be followed by a file name AND one of the symbols already detailed. 
Example: "write similarities.txt r0" will produce the r0 similarity matrix to be written in
the file "similarities.txt". 

Output:

  Leftmost outlet:
  The output is a series of lists which resembles the ordering of a triangular
  comparison matrix. Here is an example of such matrix:
  Being (A), (B), (C), (D) and (E) PCS delivered in this order, the output will be:

		(B)		(C)		(D)		(E)	
-----------------------------------
(A) |	ab		ac		ad		ae	<--(list 1 of length N-1)	
	|							   		
(B)	|			bc		bd		be	<--(list 2 of length N-2)
	|		
(C)	|					cd		ce	<--(list 3 of length N-3)
    |
(D)	|							de	<--(list 4 of length N-4)

  So, for example, to know the result of the comparison between (B) and (C) you must read
  the content of the position which is the intersection of the row labeled (B) with
  the column labeled (C), which is filled, in this case, by "bc", but actually will be filled
  by a number or a symbol.
  The example shown above is of a series of 5 PCS, so, the output will be a series of FOUR lists, each one
  being of size N-n, being N the number of PCS compared and n the number of list of the output.
  The content of each "cell" is as follows:
  Forte's similarities: A list of floats. "1" will means that the relation stands while "0" will means
  that the relation does not stands. a -100 will indicate that the PCS to be compared did not meet 
  the needed constraints for the relation and so, are not comparable.
  Other relations: a list of float values. In the case of the OI, DIS, SCAT and CC coefficients, a 
  -100 value will mean that the PCS to be compared did not meet the needed constraints for the 
  relation and so, are not comparable.

  Rightmost outlet: in the case of Forte's relations, no output. Otherwise, a list of two floats
  being the first one the maximal value and the second the minimal value found out of all the values
  obtained in the comparison.

  In the case of the "write" message there will not be output from the outlets and the data written
  in the file will have the same format explained, except that the value of -100 is replaced with
  a "(NC)" (meaning "not comparable") and in the case of Forte's relations "+" or "-" are used instead of 
  "0" or "1". Forte's rp relation may include more than one "+" since there may be more than one subset
  shared between two SC.
*/


typedef struct _pcs_sim2{
	t_object  x_obj;	
	PCS* pcs;	
	SIM **ms;
	float ranks[8][2];
	float w; /*weighting coefficient for OPSC*/
	t_float index;
	t_int npcs;
	t_int j; /* the jth col of the similarity matrix*/
	t_outlet *sim_out;
	t_outlet *ranks_out;
} t_pcs_sim2;

#define max_sim_r	100
#define max_sim_c	100
#define max_sim_n	4950 //((n*n)-n)/2	
/*****************PCS_SIM2 DEFUNCS************/
void pcs_sim2_any(t_pcs_sim2 *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_sim2_new();
void pcs_sim2_setup(void);
void pcs_sim2_destroy(t_pcs_sim2 *x);
void pcs_sim2_get_pcs(t_pcs_sim2 *x, t_symbol *s, t_int argc, t_atom *argv);
void pcs_sim2_alloc(t_pcs_sim2 *x);
void pcs_sim2_writefile(t_pcs_sim2 *x, const char *, t_int what);
void pcs_sim2_analyze(t_pcs_sim2 *x);
t_int  pcs_sim2_get_nr(const char *);
void pcs_sim2_output(t_pcs_sim2 *x, t_int what);
/*****************pcs_sim2 PROTOS*************/
/***********************************************/
void pcs_sim2_any(t_pcs_sim2 *x, t_symbol *s, t_int argc, t_atom *argv)
{
  t_int i,j;
  t_int cnt;
  t_symbol *temp, *temp2;
  t_int ri1[2], ri2[2];
  t_float result, normfac, idvm;
  t_float idv[6];
  t_int cardm[3][12];
  t_atom *ordlist;
  t_int rel;

  /*reset the PCS buffer*/
  if(strcmp(s->s_name, "reset") == 0 ) { 
	  x->npcs=0;
	  x->pcs=(PCS*)realloc(x->pcs,sizeof(PCS));
	  x->pcs[0].find[0]=EOC;
	  x->j=0;
	  /*initialize maxs and min values counter*/
	  for(i=0; i<NRELS-4; ++i) { 
		  x->ranks[i][0]=0.;
		  x->ranks[i][1]=1000.;
	  }
	  //pcs_sim2_alloc(x);
	  return;
  }

   if(x->npcs < 2) {
	  post(" pcs_sim2: just one PCS stored!");
	  return;
  }
/*deal with the write mess*/
  if(strcmp(s->s_name, "write") == 0){
	  if(argc < 2){
		  post("pcs_sim2: you need to specify a file name and a relation type");
		  return;
	  }
	  temp = atom_getsymbol(&argv[0]);
	  if((strcmp(temp->s_name, "float")) == 0 || temp == NULL) {
		  post("pcs_sim2: not a valid filename");
		  return;
	  }
	  temp2 = atom_getsymbol(&argv[1]);
	  if(temp2 == NULL){
		  post("pcs_sim2: you need to specify a relation type");
		  post("valid relations are: r0, r1, r2, rp, SIM, ASIM, ICVSIM, OI, DIS, SCAT, CC, OPSC");
		  return;
	  }
	  rel=pcs_sim2_get_nr(temp2->s_name);
	  if(rel == false){
		  post("pcs_sim2: %s is not a valid relation",temp2->s_name);
		  return;
	  }
	  if(rel == Ropsc) { /*need to pickup the weighting coefficient*/
		  if(argc < 3){
			  post("pcs_sim2: you need to add a weighting coefficient (>= 0. < 1.)");
			  return;
		  }
		  temp2 = atom_getsymbol(&argv[2]);
		  if(strcmp(temp2->s_name, "float") == 0) {
			  x->w= atom_getfloat(&argv[2]);
		  }
		  if(x->w < 0. || x->w > 1.) {
			  post("pcs_sim2: out of range weighting coefficient (must be >= 0. and < 1.)");
			  return;
		  }
		  x->ranks[7][0]=0.;
		  x->ranks[7][1]=1000.;
	  }
	  pcs_sim2_writefile(x, temp->s_name, rel);
	  return;
  } /*end write*/

  /*Any other message must be a Relation type*/

  rel=pcs_sim2_get_nr(s->s_name);
  if(rel == false){
	  post("pcs_sim2: %s is not a valid relation",s->s_name);
	  return;
  }

  if(strcmp(s->s_name, "OPSC") == 0) {  
	  if(argc < 1) {
		  post("pcs_sim2: you need to add a weighting coefficient (>= 0. < 1.)");
		  return;
	  }
	  temp = atom_getsymbol(&argv[0]);
	  if(strcmp(temp->s_name, "float") == 0) {
		  x->w= atom_getfloat(&argv[0]);
	  }
	  if(x->w < 0. || x->w > 1.) {
		  post("pcs_sim2: out of range weighting coefficient (must be >= 0. and < 1.)");
		  return;
	  }
	  x->ranks[7][0]=0.;
	  x->ranks[7][1]=1000.;
  }
  pcs_sim2_output(x, rel);
  
  return;		
}
/******************************************/
void *pcs_sim2_new()
{
  t_int i;
  t_pcs_sim2 *x = (t_pcs_sim2 *)pd_new(pcs_sim2_class);


  x->npcs=0;
  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs[0].find[0]=EOC;
  x->j=0;

  x->ms=NULL;
  //pcs_sim2_alloc(x);
  x->ms=(SIM**)malloc(sizeof(SIM*)*max_sim_c);
  for(i=0; i<max_sim_c; ++i) {
	x->ms[i]=(SIM*)malloc(sizeof(SIM)*max_sim_r-i);
  }
  //post("\n used memory= %d Kb", (max_sim_c*sizeof(SIM))/1024);
  
  /*initialize max and min values counter*/
  for(i=0; i<NRELS-4; ++i) { 
	  x->ranks[i][0]=0.;
	  x->ranks[i][1]=1000.;
  }

  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("pcs_sim2_get_pcs"));
  x->sim_out=outlet_new(&x->x_obj, &s_float);	
  x->ranks_out=outlet_new(&x->x_obj, &s_float);

  return (void *)x;
}
/******************************************/
void pcs_sim2_setup(void) {
  pcs_sim2_class = class_new(gensym("pcs_sim2"),
		       (t_newmethod)pcs_sim2_new,
		       0, sizeof(t_pcs_sim2),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addanything(pcs_sim2_class, pcs_sim2_any);	
  class_addmethod(pcs_sim2_class,(t_method)pcs_sim2_get_pcs,gensym("pcs_sim2_get_pcs"),A_GIMME,0);
}
/******************************************/
void pcs_sim2_get_pcs(t_pcs_sim2 *x, t_symbol *s, t_int argc, t_atom *argv) {

  t_symbol *temp;
  PCS *tempcs;


  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("pcs_sim2 warning: no pointer to pcs received");
    return;
  }
  
  if(x->npcs+1 >= max_sim_c) {
	post("\n pcs_sim2: maximal number of pcs input (%d) pcs reached, pcs rejected", max_sim_c);
	return;
  }
  
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  x->npcs++;
  x->pcs=(PCS*)realloc(x->pcs,x->npcs*sizeof(PCS));
  CopiaSet(tempcs,&x->pcs[x->npcs-1]);
  
  
  //pcs_sim2_alloc(x);
  
  if(x->npcs > 1) {
	  pcs_sim2_analyze(x);
  }

  return;
}
/******************************************/
void pcs_sim2_alloc(t_pcs_sim2 *x)
{
	t_int i,j;
	SIM *temp;
	
	x->ms=(SIM**)realloc(x->ms,sizeof(SIM*)*x->npcs+1);
	
	for(i=0; i<x->npcs+1; ++i) {
		temp=NULL;
		temp=(SIM*)realloc(temp,sizeof(SIM)*x->npcs+1);
		if(temp == NULL) {
			post("out of memory!");
			x->npcs-=1;
			return;
		}
		for(j=0; j<x->npcs-1; ++j) {
			if(i < x->npcs)
				temp[j]=x->ms[i][j];
		}
		x->ms[i]=temp;	
	}
	free(temp);
	return;
}

/******************************************/

void pcs_sim2_analyze(t_pcs_sim2 *x)
{
t_int i,n;
/*Do and store analysis on a similarity matrix*/
/*see above the graphics explanation on the similarity matrix structure*/
	 
for(i=0; i<x->npcs-1; ++i) {
	/*for Forte relations, PCS must meet some constraints if they don't, the result is set to NC*/
	if(x->pcs[i].ncar != x->pcs[x->j+1].ncar || x->pcs[i].nord == x->pcs[x->j+1].nord || x->pcs[i].ncar > 8 || x->pcs[x->j+1].ncar > 8 || x->pcs[i].ncar < 4 || x->pcs[x->j+1].ncar < 4) {
		x->ms[i][x->j].r0=NC;
		x->ms[i][x->j].r1=NC;
		x->ms[i][x->j].r2=NC;
		x->ms[i][x->j].rp[0]=NC;
	}
	/*do Forte analysis*/
	else{
		x->ms[i][x->j].r0=fr0(x->pcs[i].icvmat,x->pcs[x->j+1].icvmat);
		x->ms[i][x->j].r1=fr1(x->pcs[i].icvmat,x->pcs[x->j+1].icvmat);
		x->ms[i][x->j].r2=fr2(x->pcs[i].icvmat,x->pcs[x->j+1].icvmat);
		frp(&x->pcs[i],&x->pcs[x->j+1],x->ms[i][x->j].rp);
	}
	/*do other analysis and store max. and min. values in this case*/
	x->ms[i][x->j].sim=sim(x->pcs[i].icvmat,x->pcs[x->j+1].icvmat);
	x->ranks[0][0]=x->ranks[0][0] >= x->ms[i][x->j].sim? x->ranks[0][0] : x->ms[i][x->j].sim;	
	x->ranks[0][1]=x->ranks[0][1] <= x->ms[i][x->j].sim? x->ranks[0][1] : x->ms[i][x->j].sim;
	
	x->ms[i][x->j].asim=asim(x->pcs[i].icvmat,x->pcs[x->j+1].icvmat);
	x->ranks[1][0]=x->ranks[1][0] >= x->ms[i][x->j].asim? x->ranks[1][0] : x->ms[i][x->j].asim;	
	x->ranks[1][1]=x->ranks[1][1] <= x->ms[i][x->j].asim? x->ranks[1][1] : x->ms[i][x->j].asim;


	x->ms[i][x->j].icvsim=icvsim(x->pcs[i].icvmat,x->pcs[x->j+1].icvmat);
	x->ranks[2][0]=x->ranks[2][0] >= x->ms[i][x->j].icvsim? x->ranks[2][0] : x->ms[i][x->j].icvsim;	
	x->ranks[2][1]=x->ranks[2][1] <= x->ms[i][x->j].icvsim? x->ranks[2][1] : x->ms[i][x->j].icvsim;

	roi_dis_scat_cc(&x->pcs[i],&x->pcs[x->j+1],&x->ms[i][x->j]);
	x->ranks[3][0]=x->ranks[3][0] >= (float)x->ms[i][x->j].oi?  x->ranks[3][0] : (float)x->ms[i][x->j].oi;	
	x->ranks[3][1]=x->ranks[3][1] <= (float)x->ms[i][x->j].oi?  x->ranks[3][1] : (float)x->ms[i][x->j].oi;
    x->ranks[4][0]=x->ranks[4][0] >= (float)x->ms[i][x->j].dis? x->ranks[4][0] : (float)x->ms[i][x->j].dis;	
	x->ranks[4][1]=x->ranks[4][1] <= (float)x->ms[i][x->j].dis? x->ranks[4][1] : (float)x->ms[i][x->j].dis;
	x->ranks[5][0]=x->ranks[5][0] >= (float)x->ms[i][x->j].scat?x->ranks[5][0] : (float)x->ms[i][x->j].scat;	
	x->ranks[5][1]=x->ranks[5][1] <= (float)x->ms[i][x->j].scat?x->ranks[5][1] : (float)x->ms[i][x->j].scat;
	x->ranks[6][0]=x->ranks[6][0] >= x->ms[i][x->j].cc?  x->ranks[6][0] : x->ms[i][x->j].cc;	
	x->ranks[6][1]=x->ranks[6][1] <= x->ms[i][x->j].cc?  x->ranks[6][1] : x->ms[i][x->j].cc;

	opcss(&x->pcs[i],&x->pcs[x->j+1],&x->ms[i][x->j].opcss[0],&x->ms[i][x->j].opcss[1]);
	
	/**/
	
}

x->j++; //update the column number

return;
}
/******************************************/
void pcs_sim2_writefile(t_pcs_sim2 *x, const char *name, t_int what) 
{
t_int i, j, cnt=0;
char *str;
char *num;
FILE *fout;
float faux;

if((fout=fopen(name,"wt"))==NULL) {
	post("could not open %s",name);
	return;
}
/////////////////////////////////////////////
str=(char*)malloc(sizeof(char)*(PCSL*x->npcs)); 
*str=0;
num=(char*)malloc(sizeof(char)*64);
*num=0;

switch(what) {
case Rr0:
	strcat(str,"\nAllen Forte's r0 values:\n\n");
	break;
case Rr1:
	strcat(str,"\nAllen Forte's r1 values:\n\n");
	break;
case Rr2:
	strcat(str,"\nAllen Forte's r2 values:\n\n");
	break;
case Rrp:
	strcat(str,"\nAllen Forte's rp values:\n\n");
	break;
case Rsim:
	strcat(str,"\nRobert Morris's SIM values:\n\n");
	break;
case Rasim:
	strcat(str,"\nRobert Morris's ASIM values:\n\n");
	break;
case Ricvsim:
	strcat(str,"\nEric Isaacson's ICVSIM values:\n\n");
	break;
case Roi:
	strcat(str,"\nMilton Babbitt's Order Inversions values:\n\n");
	break;
case Rdis:
	strcat(str,"\nRobert Morris's Displacement values:\n\n");
	break;
case Rscat:
	strcat(str,"\nRobert Morris's Scattering values:\n\n");
	break;
case Rcc:
	strcat(str,"\nCorrelation Coefficient values:\n\n");
	break;
case Ropsc:
	*num=0;
	sprintf(num," (w=%1.3f) \n\n",x->w);
	strcat(str,"\nPablo Di Liscia's Ordered PCS Similarity Coefficient");
	strcat(str,num);
	break;
}

*num=0;
for(i=1; i<x->npcs; ++i) {
		strcat(str,"\t");
		Pname(&x->pcs[i],num);
		strcat(str, num);
	}
strcat(str,"\n");
fprintf(fout, "%s",str);


for(i=0; i<x->npcs-1; ++i) {
	*str=0;
	strcat(str,"\n");
	Pname(&x->pcs[i],num);
	strcat(str, num);
	for(j=0; j<i; ++j) {
		strcat(str,"\t"); 
	}
	for(j=i; j<x->npcs-1; ++j) {
		*num=0; 
		if(what==Rsim) { 
			sprintf(num,"\t%1.0f",x->ms[i][j].sim);
		}

		if(what==Rasim) {
			sprintf(num,"\t%1.3f",x->ms[i][j].asim);
		}
		if(what==Ricvsim) {
			sprintf(num,"\t%1.3f",x->ms[i][j].icvsim);
		}
		if(what==Roi || what==Rdis || what==Rscat) {
			if(x->ms[i][j].oi == NC || x->ms[i][j].dis==NC || x->ms[i][j].scat==NC) {
				sprintf(num,"\t(nc)");
			}
			else {
				if(what==Roi)
					sprintf(num,"\t%d",x->ms[i][j].oi);
				if(what==Rdis) 
					sprintf(num,"\t%d",x->ms[i][j].dis);
				if(what==Rscat) 
					sprintf(num,"\t%d",x->ms[i][j].scat);		
			}
		}
		if(what==Rcc) {
			if(x->ms[i][j].cc == (float)NC) 
				sprintf(num,"\t(nc)");
			else
				sprintf(num,"\t%1.3f",x->ms[i][j].cc);
		}
		if(what==Ropsc) {
			faux=x->ms[i][j].opcss[0]*(1.-x->w) + x->ms[i][j].opcss[1]*(x->w);
			sprintf(num,"\t%1.5f",faux);
			/*evaluation of min-max must be done "on the fly" in this special case*/
			x->ranks[7][0]=x->ranks[7][0] >= faux? x->ranks[7][0] : faux;	
			x->ranks[7][1]=x->ranks[7][1] <= faux? x->ranks[7][1] : faux;
		}
		if(what==Rr0 || what==Rr1 || what==Rr2 || what==Rrp) {
			switch(what) {
			case Rr0:
				if(x->ms[i][j].r0==NC) 
					sprintf(num,"\t(nc)");
				else {
					if(x->ms[i][j].r0==true)
						sprintf(num,"\t+");
					else
						sprintf(num,"\t-");
				}
				break;
			case Rr1:
				if(x->ms[i][j].r1==NC) 
					sprintf(num,"\t(nc)");
				else {
					if(x->ms[i][j].r1==true)
						sprintf(num,"\t+");
					else
						sprintf(num,"\t-");
				}
				break;
			case Rr2:
				if(x->ms[i][j].r2==NC) 
					sprintf(num,"\t(nc)");
				else {
					if(x->ms[i][j].r2==true)
						sprintf(num,"\t+");
					else
						sprintf(num,"\t-");
				}
				break;
			case Rrp:
				cnt=0;
				if(x->ms[i][j].rp[0]==NC) 
					sprintf(num,"\t(nc)");
				else {
					if(x->ms[i][j].rp[0]!=0) {
						sprintf(num,"\t");
						do{
							strcat(num,"+");
						}while(x->ms[i][j].rp[++cnt]!=0);
					}
					else
						sprintf(num,"\t-");
				}
				break;
			} 
		}
		strcat(str,num);
	}
	fprintf(fout,"%s",str);
}
/*outputs max. and min. values, if adequate*/
if(what >4 ) {
	for(i=5; i<=NRELS; ++i) {
		if(what==i) {
			sprintf(str,"\n\nMax. value= %f",x->ranks[i-5][0]);
			fprintf(fout,"%s",str);
			sprintf(str,"\nMin. value= %f",x->ranks[i-5][1]);
			fprintf(fout,"%s",str);
		}
	}
}
/////////////////////////////////////////////
free(str);
free(num);
post("Data written in %s",name);
fclose(fout);
return;
}
/******************************************/
void pcs_sim2_destroy(t_pcs_sim2 *x){
 
  t_int i;

  if(x->pcs != NULL) {
   free(x->pcs);
  }
  for(i=0; i< max_sim_c; i++) {
	free(x->ms[i]);
  }
  
  free(x->ms);

  return;	
}
/******************************************/
t_int pcs_sim2_get_nr(const char *name)
{
	if(strcmp(name, "SIM") == 0){
		return(Rsim);	
	}
	if(strcmp(name, "ASIM") == 0){
		return(Rasim);	
	}
	if(strcmp(name, "ICVSIM") == 0){
		return(Ricvsim);	
	}
	if(strcmp(name, "r0") == 0){
		return(Rr0);	
	}
	if(strcmp(name, "r1") == 0){
		return(Rr1);	
	}
	if(strcmp(name, "r2") == 0){
		return(Rr2);	
	}
	if(strcmp(name, "rp") == 0){
		return(Rrp);	
	}
	
	if(strcmp(name, "OI") == 0){
		return(Roi);	
	}
	if(strcmp(name, "DIS") == 0){
		return(Rdis);	
	}
	if(strcmp(name, "SCAT") == 0){
		return(Rscat);	
	}
	if(strcmp(name, "CC") == 0){
		return(Rcc);	
	}
	if(strcmp(name, "OPSC") == 0){
		return(Ropsc);	
	}
return(false);
}
/******************************************/
void pcs_sim2_output(t_pcs_sim2 *x, t_int what)
{
	t_atom *sarray;
	t_atom rarray[2];
	float aux;
	t_int i,j,cnt;
	
	sarray=(t_atom*)malloc(sizeof(t_atom)*x->npcs);
	
	/*outputs max. and min. values, if addequate*/
	if(what > 4 ) {
		for(i=5; i <= NRELS; ++i) {
			if(what==i) {
				SETFLOAT(&(rarray[0]),(float)x->ranks[i-5][0]);
				SETFLOAT(&(rarray[1]),(float)x->ranks[i-5][1]);
				break;
			}
		}
		outlet_list(x->ranks_out, gensym("list"),2,rarray);
	}
	/*outputs evaluation matrix*/
	for(i=0; i<x->npcs-1; ++i) {
		cnt=0;
		for(j=i; j<x->npcs-1; ++j) {
			switch(what) {
			case Rr0:
				aux=(float)x->ms[i][j].r0;
				break;
			case Rr1:
				aux=(float)x->ms[i][j].r1;
				break;
			case Rr2:
				aux=(float)x->ms[i][j].r2;
				break;
			case Rrp:
				if(x->ms[i][j].rp[0] !=0) {
					if(x->ms[i][j].rp[0] ==NC)
						aux=-100.;
					else
						aux=1.;
				}
				else
					aux=0.;
				break;		
			case Rsim:
				aux=(float)x->ms[i][j].sim;
				break;
			case Rasim:
				aux=(float)x->ms[i][j].asim;
				break;
			case Ricvsim:
				aux=(float)x->ms[i][j].icvsim;
				break;
			case Roi:
				aux=(float)x->ms[i][j].oi;
				break;
			case Rdis:
				aux=(float)x->ms[i][j].dis;
				break;
			case Rscat:
				aux=(float)x->ms[i][j].scat;
				break;
			case Rcc:
				aux=(float)x->ms[i][j].cc;
				break;
			case Ropsc:
				aux=x->ms[i][j].opcss[0]*(1.-x->w) + x->ms[i][j].opcss[1]*(x->w);
				/*evaluation of min-max must be done "on the fly" in this special case*/
				x->ranks[7][0]=x->ranks[7][0] >= aux? x->ranks[7][0] : aux;	
				x->ranks[7][1]=x->ranks[7][1] <= aux? x->ranks[7][1] : aux;
				break;			
			}
			SETFLOAT(&(sarray[cnt]),aux); 
			cnt++;
		}
		outlet_list(x->sim_out, gensym("list"),cnt,sarray);
	}
	
	free(sarray);
	return;
}
/******************************************/
