/*pcs_invar object  by Oscar Pablo Di Liscia*/
static t_class *pcs_invar_class;
/*
The pcs_invar object expects a series of pointers to  PCS structs (must be at least 2).
The pointers must be generated using the prime_form object or any other.
A "reset" message reset the list of PCS to 0.
Any other message(most likely "bang") generates the output:
outlet1: invariant pcs between all the pcs delivered  -if any-(floats list)
outlet2: number of invariant pcs between all the pcs delivered  -if any-(float)
*/
typedef struct _pcs_invar{
  t_object  x_obj;
  PCS *pcs1;	  /*pointers to PCS struct*/
  t_atom filist[PCSL];    /*invariant subset*/
  t_outlet *list_out;
  t_outlet *nin;
  t_int npcs;
} t_pcs_invar;

/*****************PCS_INVAR DEFUNCS************/
void pcs_invar_any(t_pcs_invar *x,t_symbol *s, t_int argc, t_atom *argv);
void *pcs_invar_new();
void pcs_invar_setup(void);
void pcs_invar_destroy(t_pcs_invar *x);
void pcs_invar_get_ptr1(t_pcs_invar *x, t_symbol *s, t_int argc, t_atom *argv);
/*****************PCS_INVAR PROTOS*************/
/***********************************************/
void pcs_invar_any(t_pcs_invar *x,t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int h,i,j,ptr=0, cont=0;
  PCS *tempcs=NULL;
  t_float tempf;
  t_atom *filist;
  t_symbol *temps;
  t_int aux[PCSL];

  /*reset the PCS buffer*/
  if(strcmp(s->s_name, "reset") == 0 ) { 
    x->npcs=0;
    x->pcs1=(PCS*)realloc(x->pcs1,sizeof(PCS));
    x->pcs1[0].find[0]=EOC;
    return;
  }

  if(x->npcs==0){
    post("pcs_invar warning: no pointer/s to pcs received");
    return;
  }
  if(x->npcs==1){
    post("pcs_invar warning: need at leat two PCS structs");
    return;
  }

  for(i=0; i < PCSL; ++i) { 
    aux[i]=EOP;
  }

  for(j=0; j<12; ++j) {
    cont=0;
    for(i=0; i < x->npcs; ++i) {
      h=0;
       do{
	if(x->pcs1[i].find[h]==j && x->pcs1[i].find[h] != EOP ) {
	  ++cont;
	  break;
	}
       }while(x->pcs1[i].find[h++] != EOC);
    }
    if(cont == x->npcs) { /*the pc was found on all pcs*/
      aux[ptr++]=j;
    }
  }
  
  /*output the size of the invariant set*/
  outlet_float(x->nin,(t_float)ptr);
  
  filist=x->filist;
  if(ptr != 0){
    for(i=0; i<=ptr; ++i) {
      tempf=(float)aux[i];
      SETFLOAT(&(filist[i]),tempf);
    }
    /*output the invariant set*/
    outlet_list (x->list_out, gensym("list"),ptr,x->filist);		
  }
  

  return;		
}
/******************************************/
void *pcs_invar_new()
{
  t_pcs_invar *x = (t_pcs_invar *)pd_new(pcs_invar_class);
  x->pcs1=NULL;

  x->npcs=0;
  x->pcs1=(PCS*)malloc(sizeof(PCS)); 
  x->pcs1[0].find[0]=EOC;

  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("symbol"),gensym("pcs_invar_get_ptr1"));
  x->list_out=outlet_new(&x->x_obj, &s_float);	
  x->nin=outlet_new(&x->x_obj, &s_float);

  return (void *)x;
}
/******************************************/
void pcs_invar_setup(void) {
  pcs_invar_class = class_new(gensym("pcs_invar"),
		       (t_newmethod)pcs_invar_new,
		       0, sizeof(t_pcs_invar),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addanything(pcs_invar_class, pcs_invar_any);
  class_addmethod(pcs_invar_class,(t_method)pcs_invar_get_ptr1,gensym("pcs_invar_get_ptr1"),A_GIMME,0);
}

/******************************************/
void pcs_invar_destroy(t_pcs_invar *x){

  if(x->pcs1 != NULL){
    free(x->pcs1);
  }

  return;	
}
/******************************************/
void pcs_invar_get_ptr1(t_pcs_invar *x, t_symbol *s, t_int argc, t_atom *argv) {

  t_symbol *temp;
  PCS *tempcs;

  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("pcs_invar warning: no pointer to pcs received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  x->npcs++;
  x->pcs1=(PCS*)realloc(x->pcs1,x->npcs*sizeof(PCS));
  CopiaSet(tempcs,&x->pcs1[x->npcs-1]);
  forma_prima(&x->pcs1[x->npcs-1],tableptr);
  return;
}
