/*pcs_ttos_object  by Oscar Pablo Di Liscia*/
static t_class *pcs_ttos_class;
/*
The pcs_ttos object expects a PCS struct pointer and a float(n) by
its cold inlets. If it receives a "I","T","M" or MI symbol by its
hot inlet it perform the IT(n), T(n), MT(n), MIT(n) operation (twelve-tone
operation) on the PCS.
inlet1: symbol (T, I, M or MI)
inlet2: pointer to a PCS struct
inlet3: n

TTO stands for Twelve-Tone Operator (after Morris, 1987).
There are four kind of TTOs: T, IT, MT and IMT.

Being p a PC, and n a trasposition factor, the result of each operation would be:

Tn(n,p)	=	p+n			(mod. 12)	
I (n,p)	=	(12-p)+n	(mod. 12)
M(n,p)	=	p*5 + n		(mod. 12)
MI(n,p)	=	p*7 + n		(mod. 12)

Note that the transposition is allways involved in the four operations of the TTOs even in the
trivial case where n=0.

The output is a pointer to the resulting PCS struct. To access the data, a pcs_read
object must be used.
*/

typedef struct _pcs_ttos{
	t_object  x_obj;
	PCS *pcs1;		  /*pointer to PCS struct*/
	PCS *pcs2;
	t_float n;
	t_outlet  *pcs_out;
}t_pcs_ttos;

/*****************PCS_TTOS DEFUNCS************/
void pcs_ttos_any(t_pcs_ttos *x, t_symbol *sym, t_int argc, t_atom *argv);
void *pcs_ttos_new();
void pcs_ttos_setup(void);
void pcs_ttos_set_n(t_pcs_ttos *x, t_floatarg f);
void pcs_ttos_get_ptr(t_pcs_ttos *x, t_symbol *s, t_int argc, t_atom *argv);
void pcs_ttos_destroy(t_pcs_ttos *x);
/*****************PCS_TTOS PROTOS*************/
/***********************************************/
void pcs_ttos_any(t_pcs_ttos *x, t_symbol *sy, t_int argc, t_atom *argv){
	
	t_symbol *temp_symbol;
	t_int i;
	char s[STRLP];
	t_symbol *temps;
	t_atom plist[2];
	
	if(strcmp(sy->s_name, "T") != 0 && strcmp(sy->s_name, "I") != 0 && strcmp(sy->s_name, "M") != 0 && strcmp(sy->s_name, "MI") != 0) {
		return;
	}
	
	if(x->pcs1->find[0] !=EOC) {
		if(x->pcs2->find[0]==EOC){
			CopiaSet(x->pcs1,x->pcs2);
		}
		if(strcmp(sy->s_name, "T") == 0){
			TrInvPCS(x->pcs2, FALSE, (t_int)x->n);
		}
		if(strcmp(sy->s_name, "I") == 0){
			TrInvPCS(x->pcs2, TRUE, (t_int)x->n);
		}
		if(strcmp(sy->s_name, "M") == 0){
			for(i=0; i<PCSL; i++){
				if(x->pcs2->find[i] == EOC || x->pcs2->find[i] == EOP) break;     
				x->pcs2->find[i] =x->pcs2->find[i] * 5 + (t_int)x->n;
				if(x->pcs2->find[i] > 11) {
					x->pcs2->find[i]=x->pcs2->find[i]%12;
				}
			}
			forma_prima(x->pcs2, tableptr); 
		}
		if(strcmp(sy->s_name, "MI") == 0){
			for(i=0; i<PCSL; i++){
				if(x->pcs2->find[i] == EOC || x->pcs2->find[i] == EOP) break;     
				x->pcs2->find[i] =x->pcs2->find[i] * 7 + (t_int)x->n;
				if(x->pcs2->find[i] > 11) {
					x->pcs2->find[i]=x->pcs2->find[i]%12;
				}
			}
			forma_prima(x->pcs2, tableptr); 
		}

	}
	
	/*convert pointer to PCS struct into symbol*/
	sprintf(s, "%p",x->pcs2);
	temp_symbol = gensym(s);
	temps=gensym(MPID); /*ident*/
	
	SETSYMBOL(&(plist[0]),temps);
	SETSYMBOL(&(plist[1]),temp_symbol);
	outlet_list (x->pcs_out, gensym("list"),2,plist);
	
	return;		
}

/******************************************/
void *pcs_ttos_new()
{
	t_pcs_ttos *x = (t_pcs_ttos *)pd_new(pcs_ttos_class);
	x->pcs1=NULL;
	x->pcs2=NULL;
	
	x->pcs1=(PCS*)malloc(sizeof(PCS));
	x->pcs1->find[0]=EOC;
	x->pcs2=(PCS*)malloc(sizeof(PCS));
	x->pcs2->find[0]=EOC;
	
	x->n=0.; /*transposition factor initialized to 0.*/
	
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("symbol"),gensym("get_ptr"));
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("float"),gensym("set_n"));
	
	x->pcs_out=outlet_new(&x->x_obj, &s_symbol);
	
	return (void *)x;
}
/******************************************/
void pcs_ttos_setup(void) {
	pcs_ttos_class = class_new(gensym("pcs_ttos"),
		(t_newmethod)pcs_ttos_new,
		0, sizeof(t_pcs_ttos),
		CLASS_DEFAULT,A_DEFFLOAT,0);
	
	class_addmethod(pcs_ttos_class,(t_method)pcs_ttos_set_n,gensym("set_n"),A_DEFFLOAT,0);
	class_addmethod(pcs_ttos_class,(t_method)pcs_ttos_get_ptr,gensym("get_ptr"),A_GIMME,0);
	class_addanything(pcs_ttos_class, pcs_ttos_any);	
}
/******************************************/
void pcs_ttos_set_n(t_pcs_ttos *x, t_floatarg f) {
	x->n=f;
	if(x->n >=12.) x->n-=12.;
	if(x->n < 0.)  x->n+=12.;
	return;
}
/******************************************/
void pcs_ttos_get_ptr(t_pcs_ttos *x, t_symbol *s, t_int argc, t_atom *argv) {
	t_symbol *temp;
	PCS *tempcs;
	
	if(check_ptr_mess(argc,argv,MPID)==FALSE){
		post("pcs_ttos warning: no pointer to pcs received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcs);
	CopiaSet(tempcs,x->pcs1);

	x->pcs2->find[0]=EOC;
	return;
}
/******************************************/
void pcs_ttos_destroy(t_pcs_ttos *x){
	if(x->pcs1 != NULL){
		free(x->pcs1);
	}
	return;	
}
/******************************************/
