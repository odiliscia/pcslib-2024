/*pcs_write object by Oscar Pablo Di Liscia*/
static t_class *pcs_write_class;
/*
The pcs_write object expects a list with three or four args.
cardinal number(float), ordinal number(float) and transposition factor(float).
If a fourth arg is delivered, it must be a symbol "I", which stands for
"inversion". The PCS is scanned at the PCS table and transposed and/or inverted
if required.
The output is a pointer to a PCS struct. To access the data, a pcs_read
object must be used.
*/
typedef struct _pcs_write{
  t_object  x_obj;
  PCS *pcs;/*pointer to PCS struct*/
  t_int ncar;
  t_int nord;
  t_int t;
  t_int i;
  t_outlet  *pcs_out;
} t_pcs_write;
/*****************PCS_WRITE DEFUNCS************/
void pcs_write_list(t_pcs_write *x, t_symbol *s, t_int argc, t_atom *argv);
void *pcs_write_new();
void pcs_write_setup(void);
void pcs_write_destroy(t_pcs_write *x);
/*****************PCS_WRITE PROTOS*************/
/***********************************************/
void pcs_write_list(t_pcs_write *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int i; 
  t_symbol *temp_symbol;
  char pstr[STRLP]; 
  t_symbol *temps;
  t_atom plist[2];
  t_int tpos[7]={0,12,41,79,129,167,196};
  t_int nc[7]={12,29,38,50,38,29,12};
  t_int ptr=0;

  if(argc < 3) {
    post("pcs_write: need a list with 3 args: cardinal(float) ordinal(float) t(float) I(optional)");
    return;
  }

  /*pickup a list with args*/
  temp = atom_getsymbol(&argv[0]);
  if(strcmp(temp->s_name, "float") == 0)
    x->ncar =(t_int)atom_getfloat(&argv[0]);
  if(x->ncar < 3 || x->ncar > 9 ) {
    post("pcs_write: cardinal number must be between 3 and 9");
    return;
  }
  
 
  temp = atom_getsymbol(&argv[1]);
  if(strcmp(temp->s_name, "float") == 0)
    x->nord =(t_int)atom_getfloat(&argv[1]);
  if(x->nord > nc[x->ncar-3]) {
    post("pcs_write: the SC %d-%d does not exist!",x->ncar,x->nord);
    return;
  }

  temp = atom_getsymbol(&argv[2]);
  if(strcmp(temp->s_name, "float") == 0)
    x->t =(t_int)atom_getfloat(&argv[2]);
 
  if(argc > 3)
  temp = atom_getsymbol(&argv[3]);
  if(strcmp(temp->s_name, "I") == 0) { 
    x->i =TRUE;
  }
  else{
    x->i =FALSE;
  }
  
  ptr=((tpos[x->ncar-3] + x->nord-1)*20);
  x->pcs->ncar=tableptr[ptr];
  x->pcs->nord=tableptr[ptr+1];
  for(i=0; i<x->pcs->ncar; i++) {
    x->pcs->find[i]=tableptr[i+ptr+2];
  }
  x->pcs->find[i]=EOC;
  //x->pcs->nele   = x->pcs->ncar;
  /*find prime form*/
  forma_prima(x->pcs, tableptr);
  /*need trasposition and/or inversion?*/
  if(x->i == TRUE ) {
    TrInvPCS(x->pcs,TRUE,x->t);
  }
  else
    TrInvPCS(x->pcs,FALSE,x->t);

  forma_prima(x->pcs, tableptr); 

  /*convert pointer to PCS struct into symbol*/
  sprintf(pstr, "%p", x->pcs);
  temp_symbol = gensym(pstr);
  temps=gensym(MPID); /*ident*/

  SETSYMBOL(&(plist[0]),temps);
  SETSYMBOL(&(plist[1]),temp_symbol);
  outlet_list (x->pcs_out, gensym("list"),2,plist);

  return;		
}
/******************************************/
void *pcs_write_new()
{
  t_pcs_write *x = (t_pcs_write *)pd_new(pcs_write_class);
  x->pcs=NULL;
  
  if(tableptr==NULL) {
    post("pcs_write: PCS table not allocated!");
    return(NULL);
  }
	
  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;
  
  x->pcs_out=outlet_new(&x->x_obj, &s_list);

  return (void *)x;
}
/******************************************/
void pcs_write_setup(void) {
  pcs_write_class = class_new(gensym("pcs_write"),
		       (t_newmethod)pcs_write_new,
		       0, sizeof(t_pcs_write),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addlist(pcs_write_class, pcs_write_list);	
}
/******************************************/
void pcs_write_destroy(t_pcs_write *x){

  if(x->pcs != NULL){
    free(x->pcs);
  }
  return;	
}
/******************************************/
