/*pcslib.c by Oscar Pablo Di Liscia*/

#include "common/m_pd.h"
/*pcslib main header*/
#include "common/pcslib.h"

/*common funcs definitions*/
#include "common/pcs_funcs.c"
#include "common/cm_funcs.c"
#include "common/sim_funcs.c"
#include "common/part_funcs.c"
#include "common/ttos_funcs.c"

/*external objects*/
#include "pcs/pcs_pf.c"
#include "pcs/pcs_read.c"
#include "pcs/pcs_ttos.c"
#include "pcs/pcs_invar.c"
#include "pcs/pcs_sim.c"
#include "pcs/pcs_kh.c"
#include "pcs/pcs_sim2.c"
#include "pcs/pcs_write.c"
#include "pcs/pcs_subs.c"
#include "pcs/pcs_parts.c"
#include "pcs/pcs_2txt.c"
#include "pcs/pcs_chain.c"
#include "pcs/pcs_perm.c"
#include "pcs/pcs_2midi.c"

#include "cm/cm_roman.c"
#include "cm/cm_read.c"
#include "cm/cm_t1a.c"
#include "cm/cm_t1b.c"
#include "cm/cm_t2.c"
#include "cm/cm_opcy.c"
#include "cm/cm_2txt.c"
#include "cm/cm_2pcs.c"
#include "cm/cm_trans.c"
#include "cm/cm_ana.c"
#include "cm/cm_maker.c"
#include "cm/cm_ttog.c"


void pcslib_setup(){

  post("\nPCSLIB V.1.8 January 2024 loaded \nPablo Di Liscia and Pablo Cetta \nUniversidad Nacional de Quilmes, Argentina\n");
   
  /*setup for each external*/
  pcs_pf_setup(); 
  pcs_read_setup();
  pcs_write_setup();
  pcs_ttos_setup();
  pcs_invar_setup();
  pcs_sim_setup();
  pcs_kh_setup();
  pcs_sim2_setup();
  pcs_subs_setup();
  pcs_parts_setup();
  pcs_2txt_setup();
  pcs_chain_setup();
  pcs_perm_setup();
  pcs_2midi_setup();

  cm_roman_setup();
  cm_read_setup();
  cm_t1a_setup();
  cm_t1b_setup();
  cm_t2_setup();
  cm_opcy_setup();
  cm_2txt_setup();
  cm_2pcs_setup();
  cm_trans_setup();
  cm_ana_setup();
  cm_maker_setup();
  cm_ttog_setup();
  
  return;
}
/*************************************************/
t_int check_ptr_mess(t_int argc, t_atom *argv, char* what)
{
  t_symbol *temp;
  void *tempcs;

  if(argc !=2) return(FALSE);

  temp = atom_getsymbol(&argv[0]);

  if(strcmp(what, MMID)==0){
    if(strcmp(temp->s_name, MMID) != 0)
      return(FALSE);
    else
      return(TRUE);
  }

  if(strcmp(what, MPID)==0){
    if(strcmp(temp->s_name, MPID) != 0)
      return(FALSE);
    else
      return(TRUE);
  }
  return(TRUE);
}
