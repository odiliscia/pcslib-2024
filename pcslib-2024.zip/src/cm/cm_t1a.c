/*cm_t1a object  by Oscar Pablo Di Liscia*/
static t_class *cm_t1a_class;
/*
The cm_t1a object expects a pointer to a PCS struct.
The output is a pointer to a CM struct. To access the data, a cm_read
object must be used.
*/
typedef struct _cm_t1a{
  t_object  x_obj;
  PCS *pcs;		  /*pointer to PCS struct*/
  CM  *cm;
  t_outlet  *cm_out, *cm_nrc;
} t_cm_t1a;
/*****************CM_T1A DEFUNCS************/
void cm_t1a_any(t_cm_t1a *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_t1a_new();
void cm_t1a_setup(void);
void cm_t1a_destroy(t_cm_t1a *x);
/*****************CM_T1A PROTOS*************/
/***********************************************/
void cm_t1a_any(t_cm_t1a *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int i; 
  t_symbol *temp_symbol;
  char pstr[STRLP]; 
  t_symbol *temps;
  t_atom plist[2];
  PCS *tempcs;

  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("cm_t1a: no pointer to pcs received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  CopiaSet(tempcs, x->pcs);
  /*Build the cm*/
  MatTipo1a(x->cm, x->pcs);
  
   /*output Number of rows and cols*/
  SETFLOAT(&(plist[0]),(float)x->cm->NroFilas);
  SETFLOAT(&(plist[1]),(float)x->cm->NroCols);
  outlet_list(x->cm_nrc, gensym("list"),2,plist);
  /*convert pointer to CM struct into symbol*/
  sprintf(pstr, "%p", x->cm);
  temp_symbol = gensym(pstr);
  temps=gensym(MMID); /*ident*/
  /*output a cm struct pointer*/
  SETSYMBOL(&(plist[0]),temps);
  SETSYMBOL(&(plist[1]),temp_symbol);
  outlet_list (x->cm_out, gensym("list"),2,plist);

  return;		
}
/******************************************/
void *cm_t1a_new()
{
  t_cm_t1a *x = (t_cm_t1a *)pd_new(cm_t1a_class);
  x->pcs=NULL;
	
  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;
  x->cm=(CM*)malloc(sizeof(CM));
  Inicializar(x->cm);
  
  x->cm_out=outlet_new(&x->x_obj, &s_list);
  x->cm_nrc=outlet_new(&x->x_obj, &s_list);

  return (void *)x;
}
/******************************************/
void cm_t1a_setup(void) {
  cm_t1a_class = class_new(gensym("cm_t1a"),
		       (t_newmethod)cm_t1a_new,
		       0, sizeof(t_cm_t1a),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addlist(cm_t1a_class, cm_t1a_any);	
}
/******************************************/
void cm_t1a_destroy(t_cm_t1a *x){

  if(x->pcs != NULL){
    free(x->pcs);
  }
 if(x->cm != NULL){
    free(x->cm);
  }

  return;	
}
/******************************************/
