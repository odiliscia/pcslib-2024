/*cm_ana object by Oscar Pablo Di Liscia*/
static t_class *cm_ana_class;
/*
The cm_ana object expects a pointer to a CM struct in its right inlet.
The pointer must be generated using one of the cm objects.
It then scan the CM and analyses it according to the messages received
in its left inlet.
*/

typedef struct _cm_ana{
  t_object  x_obj;
  CM *cm;   /*pointer to a CM struct*/
  PCS *pcs, *pcs2;
  t_int c;
  t_int r;
  t_outlet *frag_out,*spar_out,*hist_out,*aset_out;
  t_atom hist[12];
  t_atom aset[12];
} t_cm_ana;

/*****************CM_ANA DEFUNCS************/
void cm_ana_any(t_cm_ana *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_ana_new();
void cm_ana_setup(void);
void cm_ana_get(t_cm_ana *x, t_symbol *s, t_int argc, t_atom *argv);
void cm_ana_destroy(t_cm_ana *x);
/*****************CM_ANA PROTOS*************/
/*******************************************/
void cm_ana_any(t_cm_ana *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int i,i2,j,j2,offset,c,cnt;
  t_symbol *temp_symbol;
  char str[STRLP];
  t_symbol *temps; 
  t_atom plist[2];
  t_float fr, sp, tempf;
  t_float pfa[12];
  t_atom *pfalist;
  t_float ast[12];
  t_atom *astlist;

  /*LOOK FOR VALID OPTIONS*/
  if(strcmp(s->s_name, "FRAG") == 0 || strcmp(s->s_name, "SPAR") == 0 || strcmp(s->s_name, "HIST") == 0 ) {
 
    /*Fragmentation coefficient requested, See Morris, 1984*/
    if(strcmp(s->s_name, "FRAG") == 0) {
      fr=frag(x->cm);
      outlet_float(x->frag_out,fr);	
      return;
    }
    /*Sparseness coefficient requested, See Morris, 1984*/
    if(strcmp(s->s_name, "SPAR") == 0) {
      sp=spar(x->cm);
      outlet_float(x->spar_out,sp);
      return;
    }
    /*Histogram(Pitch-frequency array, See Morris, 1984) requested*/
    if(strcmp(s->s_name, "HIST") == 0) {
      hist(x->cm,pfa);
      pfalist=x->hist;
      for(i=0; i<12; ++i) {
		  tempf=pfa[i];
		  SETFLOAT(&(pfalist[i]),tempf);
      }
      outlet_list(x->hist_out, gensym("list"),12,x->hist);
      return;
    }
	
	/*Order Inversions (See Babbitt, 1960, Morris, 1987) requested*/
    if(strcmp(s->s_name, "OI") == 0) {
		/*averiguar si la norma vertical es == que la horizontal*/
		/*pensar en como tratar las "inversiones de orden" cuando hay repeticiones*/
		/*evaluar los cambios de orden de las filas tomando como referencia la 1ra fila*/
		/*evaluar los cambios de orden de las columnas tomando como referencia la 1ra columna*/
		/*guardar y entregar los datos en y como?*/
		post("not yet implemented, sorry");
		return;
    }
	/*Association Set/s requested*/
	/*not yet ready, more to work on*/
    if(strcmp(s->s_name, "ASET") == 0) {
		post("not yet implemented, sorry");
		return;
		astlist=x->aset;
		
		for(i=0; i<x->cm->NroFilas; ++i) {
			for(j=0; j<x->cm->NroCols; ++j) {
				
				pos_to_pcs(x->cm, x->pcs, i, j);
				cnt=0;
				
				for(i2=0; i2<x->cm->NroFilas; ++i2) {
					for(j2=0; j2<x->cm->NroCols; ++j2) {
						if(i != i2 && j != j2) {
							pos_to_pcs(x->cm, x->pcs2, i2, j2);
							if(x->pcs->find[0] != EOC && x->pcs2->find[0] != EOC)
								if(pcs_find(x->pcs,x->pcs2) == true)  ++cnt;	
						}
					}/*j2*/
				}/*i2*/
				if(cnt != 0) {
					for(c=0; c<12; c++) {
						if(x->pcs->find[c]==EOC) 
							break;
						tempf=(float)x->pcs->find[c];
						SETFLOAT(&(astlist[c]),tempf);
					}
					outlet_list(x->aset_out, gensym("list"),c,x->aset);
				}
			}/*j*/
		}/*i*/
		return;
	}

	
  }/*valid options ends here*/

  post("cm_ana: valid options are: FRAG, SPAR or HIST");
  
  return;		
}
/******************************************/
void *cm_ana_new()
{
  t_cm_ana *x = (t_cm_ana *)pd_new(cm_ana_class);
  x->cm=NULL;

  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;

  x->pcs2=(PCS*)malloc(sizeof(PCS));
  x->pcs2->find[0]=EOC;

  x->cm=(CM*)malloc(sizeof(CM));
  Inicializar(x->cm);

  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("float"),gensym("cm_ana_get"));
  x->frag_out=outlet_new(&x->x_obj, &s_symbol);
  x->spar_out=outlet_new(&x->x_obj, &s_symbol);
  x->hist_out=outlet_new(&x->x_obj, &s_symbol);
  x->aset_out=outlet_new(&x->x_obj, &s_symbol);
  return (void *)x;
}
/******************************************/
void cm_ana_setup(void) {
  cm_ana_class = class_new(gensym("cm_ana"),
		       (t_newmethod)cm_ana_new,
		       0, sizeof(t_cm_ana),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addmethod(cm_ana_class,(t_method)cm_get,gensym("cm_ana_get"),A_GIMME,0);
  class_addanything(cm_ana_class, cm_ana_any);	
}
/******************************************/
void cm_ana_get(t_cm_ana *x, t_symbol *s, t_int argc, t_atom *argv) {
  t_symbol *temp;
  CM *tempcm;
  
  if(check_ptr_mess(argc,argv,MMID)==FALSE){
    post("cm_trans warning: no pointer to cm received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcm);
  CopiaMatriz(tempcm, x->cm);

  return;
}
/******************************************/
void cm_ana_destroy(t_cm_ana *x){

  if(x->cm != NULL){
    free(x->cm);
  }
  if(x->pcs != NULL){
    free(x->pcs);
  }
  if(x->pcs != NULL){
    free(x->pcs2);
  }
  return;	
}
/******************************************/
