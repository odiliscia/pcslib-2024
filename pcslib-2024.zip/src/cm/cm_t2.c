/*cm_t2 object  by Oscar Pablo Di Liscia*/
static t_class *cm_t2_class;
/*
The cm_t2 object expects two pointers to PCS structs(for the
horizontal and vertical norms).
The output is a pointer to a CM struct. To access the data, a cm_read
object must be used.
*/
typedef struct _cm_t2{
  t_object  x_obj;
  PCS *pcs1; /*pointer to PCS struct1*/
  PCS *pcs2; /*pointer to PCS struct2*/
  CM  *cm;   /*pointer to CM struct*/
  t_outlet  *cm_out, *cm_nrc;
} t_cm_t2;
/*****************CM_T2 DEFUNCS************/
void cm_t2_any(t_cm_t2 *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_t2_new();
void cm_t2_setup(void);
void t2get_pcs2(t_cm_t2 *x, t_symbol *s, t_int argc, t_atom *argv);
void cm_t2_destroy(t_cm_t2 *x);
/*****************CM_T2 PROTOS*************/
/***********************************************/
void cm_t2_any(t_cm_t2 *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int i; 
  t_symbol *temp_symbol;
  char pstr[STRLP]; 
  t_symbol *temps;
  t_atom plist[2];
  PCS *tempcs;

  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("cm_t2: no pointer to pcs received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  CopiaSet(tempcs, x->pcs1);

  if(x->pcs1->find[0]==EOC || x->pcs2->find[0]==EOC) {
    post("cm_t2: one or both pointers to pcs not received");
    return;
  }
  /*Build the cm*/
  MatTipo2(x->cm, x->pcs1,x->pcs2);
  
  /*output Number of rows and cols*/
  SETFLOAT(&(plist[0]),(float)x->cm->NroFilas);
  SETFLOAT(&(plist[1]),(float)x->cm->NroCols);
  outlet_list(x->cm_nrc, gensym("list"),2,plist);
  /*convert pointer to CM struct into symbol*/
  sprintf(pstr, "%p", x->cm);
  temp_symbol = gensym(pstr);
  temps=gensym(MMID); /*ident*/
  /*output a cm struct pointer*/
  SETSYMBOL(&(plist[0]),temps);
  SETSYMBOL(&(plist[1]),temp_symbol);
  outlet_list (x->cm_out, gensym("list"),2,plist);

  return;		
}
/******************************************/
void *cm_t2_new()
{
  t_cm_t2 *x = (t_cm_t2 *)pd_new(cm_t2_class);
  x->pcs1=NULL;
  x->pcs2=NULL;
	
  x->pcs1=(PCS*)malloc(sizeof(PCS));
  x->pcs1->find[0]=EOC;
  x->pcs2=(PCS*)malloc(sizeof(PCS));
  x->pcs2->find[0]=EOC;
  x->cm=(CM*)malloc(sizeof(CM));
  Inicializar(x->cm);
  x->cm_out=outlet_new(&x->x_obj, &s_list);
  x->cm_nrc=outlet_new(&x->x_obj, &s_list);

  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("t2get_pcs2"));

  return (void *)x;
}
/******************************************/
void cm_t2_setup(void) {
  cm_t2_class = class_new(gensym("cm_t2"),
		       (t_newmethod)cm_t2_new,
		       0, sizeof(t_cm_t2),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addlist(cm_t2_class, cm_t2_any);
  class_addmethod(cm_t2_class,(t_method)t2get_pcs2,gensym("t2get_pcs2"),A_GIMME,0);
}
/******************************************/
void t2get_pcs2(t_cm_t2 *x, t_symbol *s, t_int argc, t_atom *argv)
{
  t_symbol *temp;
  PCS *tempcs;

  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("pcs_t2 warning: no pointer to pcs2 received");
    return;
  }
 temp = atom_getsymbol(&argv[1]);
 /*get the pointer to a PCS struct*/
 sscanf(temp->s_name, "%p", &tempcs);
 CopiaSet(tempcs, x->pcs2);
 
 return;
}
/******************************************/
void cm_t2_destroy(t_cm_t2 *x){

  if(x->pcs1 != NULL){
    free(x->pcs1);
  }
  if(x->pcs2 != NULL){
    free(x->pcs2);
  }
  if(x->cm != NULL){
    free(x->cm);
  }

  return;	
}
/******************************************/
