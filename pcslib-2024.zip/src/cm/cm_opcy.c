/*cm_opcy object  by Oscar Pablo Di Liscia*/
static t_class *cm_opcy_class;
/*
The cm_opcy object expects one pointer to a PCS struct(right inlet)and one float
for making a CM using cycles of operators(left inlet). The float must be one, and only
one, of the following list:

  6, -6 (6 inversion), 2, 3, 4, 8, 9, or 10.
  
	The output is a pointer to a CM struct. 
*/
typedef struct _cm_opcy{
	t_object  x_obj;
	PCS *pcs; /*pointer to PCS struct*/
	CM  *cm;   /*pointer to CM struct*/
	t_outlet  *cm_out;
	t_outlet *cm_nrc; /*output for number of row and cols*/
} t_cm_opcy;
/*****************CM_OPCY DEFUNCS************/
void cm_opcy_any(t_cm_opcy *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_opcy_new();
void cm_opcy_setup(void);
void get_norm(t_cm_opcy *x, t_symbol *s, t_int argc, t_atom *argv);
void cm_opcy_destroy(t_cm_opcy *x);
/*****************CM_OPCY PROTOS*************/
/***********************************************/
void cm_opcy_any(t_cm_opcy *x, t_symbol *s, t_int argc, t_atom *argv){
	 
	t_symbol *temp_symbol, *temp;
	t_symbol *temps;
	t_atom plist[2];
	char pstr[STRLP];
	t_int TnI;
	
	
	if(x->pcs->find[0]==EOC) {
		post("cm_opcy: pointer to pcs not received");
		return;
	}
	
    temp = atom_getsymbol(&argv[0]);

    if(strcmp(temp->s_name, "float") == 0){
		TnI =(t_int)atom_getfloat(&argv[0]);

		if(TnI == 5 || TnI == 7 || TnI > 10) {
			post("cm_opcy: wrong cycles operator, valid choices are: -6, 6, 2, 3, 4, 8, 9 or 10");
			return;
		}
		if(TnI < 2) {
			if(TnI != -6) {
				post("cm_opcy: wrong cycles operator, valid choices are: -6, 6, 2, 3, 4, 8, 9 or 10");
				return;
			}
			else {
				TnI=abs(TnI)+INVERT; /*invert*/
			}
		}
		if(MatFCycles(x->cm, x->pcs,TnI)==FALSE)  {
			post("cm_opcy: could not make the CM with this PCS");
			return;
		}

		/*convert pointer to CM struct into a symbol*/
		sprintf(pstr, "%p", x->cm);
		temp_symbol = gensym(pstr);
		temps=gensym(MMID); /*ident*/
		/*output Numer of rows and cols*/
		SETFLOAT(&(plist[0]),(float)x->cm->NroFilas);
		SETFLOAT(&(plist[1]),(float)x->cm->NroCols);
		outlet_list(x->cm_nrc, gensym("list"),2,plist);
		/*output a cm struct pointer*/
		SETSYMBOL(&(plist[0]),temps);
		SETSYMBOL(&(plist[1]),temp_symbol);
		outlet_list (x->cm_out, gensym("list"),2,plist);
		
		
	}
	return;		
}
/******************************************/
void *cm_opcy_new()
{
	t_cm_opcy *x = (t_cm_opcy *)pd_new(cm_opcy_class);
	x->pcs=NULL;
	
	x->pcs=(PCS*)malloc(sizeof(PCS));
	x->pcs->find[0]=EOC;
	x->cm=(CM*)malloc(sizeof(CM));
	Inicializar(x->cm);
	x->cm_out=outlet_new(&x->x_obj, &s_list);
	x->cm_nrc=outlet_new(&x->x_obj, &s_list);
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("get_norm"));
	
	return (void *)x;
}
/******************************************/
void cm_opcy_setup(void) {
	cm_opcy_class = class_new(gensym("cm_opcy"),
		(t_newmethod)cm_opcy_new,
		0, sizeof(t_cm_opcy),
		CLASS_DEFAULT,A_DEFFLOAT,0);
	class_addanything(cm_opcy_class, cm_opcy_any);
	class_addmethod(cm_opcy_class,(t_method)get_norm,gensym("get_norm"),A_GIMME,0);
}
/******************************************/
void get_norm(t_cm_opcy *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_symbol *temp;
	PCS *tempcs;
	
	if(check_ptr_mess(argc,argv,MPID)==FALSE){
		post("pcs_opcy warning: no pointer to pcs received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcs);
	CopiaSet(tempcs, x->pcs);
	
	return;
}
/******************************************/
void cm_opcy_destroy(t_cm_opcy *x){
	
	if(x->pcs != NULL){
		free(x->pcs);
	}
	
	if(x->cm != NULL){
		free(x->cm);
	}
	
	return;	
}
/******************************************/
