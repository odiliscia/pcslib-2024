/*cm_2txt object  by Oscar Pablo Di Liscia*/
static t_class *cm_2txt_class;
/*
The cm_2txt object expects a pointer to a CM struct.
The pointer must be generated using one of the cm_ objects.
This object has no output, only post to the pd prompt a
"clean" i.e., not raw, version of the CM.
*/
typedef struct _cm_2txt{
  t_object  x_obj;
  CM *cm;   /*pointer to a CM struct*/
} t_cm_2txt;

/*****************CM_2TXT DEFUNCS************/
void cm_2txt_list(t_cm_2txt *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_2txt_new();
void cm_2txt_setup(void);
void cm_2txt_destroy(t_cm_2txt *x);
/*****************CM_2TXT PROTOS*************/
/***********************************************/
void cm_2txt_list(t_cm_2txt *x, t_symbol *s, t_int argc, t_atom *argv){
	t_symbol *temp;
	t_int Flag = TRUE;
	t_int ContElem = 0, n, j, i;
	char *str;
	char *num;
	CM *tempcm;
	
	if(check_ptr_mess(argc,argv,MMID)==FALSE){
		post("cm_2txt warning: no pointer to CM received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcm);
	CopiaMatriz(tempcm, x->cm);
	
	/*print the CM on the PD prompt*/
	str=(char*)malloc(sizeof(char)*(MAXELEM+1)); 
	*str=0;
	num=(char*)malloc(sizeof(char)*4);
	*num=0;

	strcat(str,"\n");
	for(j = 0; j < x->cm->NroFilas; j++){
		for(i = 0; i < NEXTC * x->cm->NroCols; i++){
			if(x->cm->mat[i][j] == SPAC){
				if(Flag==TRUE){
					for(n = 0; n < x->cm->MaxElemxPos-ContElem; n++)
						strcat(str," ");
					Flag = FALSE;  
					ContElem = 0;
					strcat(str,"\t");
				}
			}
			else{
				Flag = TRUE;  ContElem++;
				if(x->cm->mat[i][j] == 10)strcat(str,"A");
				else if(x->cm->mat[i][j] == 11)strcat(str,"B");
				else if(x->cm->mat[i][j] == ETY)strcat(str," ");
				else {
					*num=0; 
					sprintf(num,"%d",x->cm->mat[i][j]);
					strcat(str,num);
				}
			}
		}
		/*because each "post" calling will generate one new line on pd"*/
		post("%s \n",str);
		*str=0;
	}
	free(str);free(num);
	return;		
}
/******************************************/
void *cm_2txt_new()
{
  t_cm_2txt *x = (t_cm_2txt *)pd_new(cm_2txt_class);
  x->cm=NULL;

  x->cm=(CM*)malloc(sizeof(CM));
  Inicializar(x->cm);
  return (void *)x;
}
/******************************************/
void cm_2txt_setup(void) {
  cm_2txt_class = class_new(gensym("cm_2txt"),
		       (t_newmethod)cm_2txt_new,
		       0, sizeof(t_cm_2txt),
		       CLASS_DEFAULT,A_DEFFLOAT,0);

  class_addlist(cm_2txt_class, cm_2txt_list);	
}

/******************************************/
void cm_2txt_destroy(t_cm_2txt *x){

  if(x->cm != NULL){
    free(x->cm);
  }
  return;	
}
/******************************************/
