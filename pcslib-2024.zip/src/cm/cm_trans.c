/*cm_trans_object  by Oscar Pablo Di Liscia*/
static t_class *cm_trans_class;
/*
The cm_trans object expects a CM struct pointer in
its cold inlet. It then perform a transformation of
the CM according with the following arguments which
must be delivered in its hot inlet:
T(symbol) n(float): Trasposition by n
I(symbol) n(float): Inversion followed by Trasposition by n
RD(symbol) n(float): Rotation by the diagonal, n=0 means left bottom, n=1 means right top
R90(symbol): 90 degrees rotation
ER(symbol) r1(float) r2(float): exchange row r1 and row r2 contents.
EC(symbol) c1(float) c2(float): exchange column c1  and column c2 contents.

  SWAP(symbol): attempts to decrease the density of the CM positions by swapping its rows and columns.
  SWAP(symbol) n(float): attempts to decrease the density of the CM positions by swapping n times only its rows and columns.
  SWAP(symbol) r1(float),c1(float),r2(float),c2(float): attempts to swap the common PCs in the position at (r1,c1) by the ones at (r2,c2).
  
	DEL(symbol) r(float),c(float): erase the PCS at position r,c.
	
	  WRI(symbol) r(float),c(float): write the PCs of the PCS delivered in the second inlet at the position r,c. The PCS at this position,
	  if any, will be replaced by the new one.
	  ADD(symbol) r(float),c(float): add the PCs of the PCS delivered in the second inlet at the position r,c. The PCS at this position,
	  if any, will be added to the new one.
	  
		new:
		
		  M(symbol) n(float):  M  followed by Trasposition by n on all the CM.
		  MI(symbol) n(float): MI followed by Trasposition by n on all the CM.
		  
			TR(symbol) n(float) r(float):  T by n on the row r.
			TC(symbol) n(float) r(float):  T by n on the column r.
			
			  IR(symbol) n(float) r(float):  IT by n on the row r.
			  IC(symbol) n(float) r(float):  IT by n on the column r.
			  
				MR(symbol) n(float) r(float):  MT by n on the row r.
				MC(symbol) n(float) r(float):  MT by n on the column r.
				
				  MIR(symbol) n(float) r(float):  MIT by n on the row r.
				  MIC(symbol) n(float) r(float):  MIT by n on the column r.
				  
					
					  RW(symbol) float(n)	writes a PCS in the row n, the (partial) order of the PCS (if any) is taken in account.
					  CW(symbol) float(n)	writes a PCS in the column n, the (partial) order of the PCS (if any) taken in account.
					  
						
						 The output is a pointer to the resulting (possibly transformed) CM struct. 
						 To access the data, any of the cm readers objects must be used.
*/
typedef struct _cm_trans{
	t_object  x_obj;
	CM *cm1;		  /*pointers to CM structs*/
	CM *cm2;
	PCS *pcs;
	t_int n;        /*transposition operator*/
	t_int cmnew;
	t_int row[2];
	t_int col[2];
	t_outlet *cm_out;
}t_cm_trans;

/*****************CM_TRANS DEFUNCS************/
void cm_trans_any(t_cm_trans *x, t_symbol *sym, t_int argc, t_atom *argv);
void *cm_trans_new();
void cm_trans_setup(void);
void cm_trans_get_cm(t_cm_trans *x, t_symbol *s, t_int argc, t_atom *argv);
void cm_trans_get_pcs(t_cm_trans *x, t_symbol *s, t_int argc, t_atom *argv);
void cm_trans_destroy(t_cm_trans *x);
/*****************CM_TRANS PROTOS*************/
/***********************************************/
void cm_trans_any(t_cm_trans *x, t_symbol *sy, t_int argc, t_atom *argv){
	
	t_symbol *temp_symbol;
	t_int i, ifac, n[2], tto;
	char s[STRLP];
	t_symbol *temps, *temp;
	t_atom clist[2];
	t_int flag = FALSE, tipo = 0, nop=0;
	t_int j, z, w, h, c, d;
	t_int dens[MAXROWS][MAXROWS];
	PCS p1, p2, target;
	
	/*valid options starts here*/
	if(strcmp(sy->s_name, "T") == 0 || strcmp(sy->s_name, "I") == 0   || strcmp(sy->s_name, "RD") == 0   || strcmp(sy->s_name, "R90") == 0 || 
		strcmp(sy->s_name, "ER") == 0   || strcmp(sy->s_name, "EC") == 0  || strcmp(sy->s_name, "SWAP") == 0 || strcmp(sy->s_name, "DEL") == 0 || 
		strcmp(sy->s_name, "WRI") == 0  || strcmp(sy->s_name, "ADD") == 0 || strcmp(sy->s_name, "M") == 0    || strcmp(sy->s_name, "MI") == 0  ||
		strcmp(sy->s_name, "CW") == 0   || strcmp(sy->s_name, "RW") == 0) {
		
		
		
		if(x->cmnew == TRUE){
			CopiaMatriz(x->cm1,x->cm2);
			x->cmnew=FALSE;
		}
		
		/*TTOs on all the CM*/
		if(strcmp(sy->s_name, "T") == 0 || strcmp(sy->s_name, "I") ==0 || strcmp(sy->s_name, "M") == 0 || strcmp(sy->s_name, "MI") == 0 ) {  
			if(strcmp(sy->s_name, "T") == 0){
				tto=T_O;
			}
			if(strcmp(sy->s_name, "I") == 0){
				tto=IT_O;
			}
			if(strcmp(sy->s_name, "M") == 0){
				tto=MT_O;
			}
			if(strcmp(sy->s_name, "MI") == 0){
				tto=IMT_O;
			}
			if(argc < 1) {
				x->n=0;
			}
			else {
				temp = atom_getsymbol(&argv[0]);
				if(strcmp(temp->s_name, "float") == 0){
					x->n= (t_int)atom_getfloat(&argv[0]);
				}
			}
			cm_tto(x->cm2, tto, x->n);
		}
		/*Diagonal rotation*/   
		if(strcmp(sy->s_name, "RD") == 0 ) {   
			if(x->cm2->NroFilas != x->cm2->NroCols){
				post("cm_trans: need a square cm for this operation");
				return;
			}
			if(argc < 1) {
				post("cm_trans: need a float(0 or 1) for direction of rotation");
				return;
			}
			temp = atom_getsymbol(&argv[0]);
			if(strcmp(temp->s_name, "float") == 0){
				x->n= atom_getfloat(&argv[0]);
			}
			RotaDiag(x->cm2, (t_int)x->n);
		}
		/*90 degrees rotation*/
		if(strcmp(sy->s_name, "R90") == 0) { 
			Rota90(x->cm2);
		}
		/*Row or column exchange*/ 
		if(strcmp(sy->s_name, "ER") == 0 || strcmp(sy->s_name, "EC") == 0 ) {     
			if(argc < 2) {
				post("cm_trans: need two floats for this operation");
				return;
			}
			for(i=0; i<2; ++i) {
				temp = atom_getsymbol(&argv[i]);
				if(strcmp(temp->s_name, "float") == 0){
					n[i]= (t_int)fabs(atom_getfloat(&argv[i]));
				}
			}
			if(strcmp(sy->s_name, "ER") == 0){
				if(n[0] > x->cm2->NroFilas || n[1] > x->cm2->NroFilas ){
					post("cm_trans: the cm doesn't have the number of row requested");
					return;
				}
				InterFilas(x->cm2,n[0],n[1]);
			}
			if(strcmp(sy->s_name, "EC") == 0){
				if(n[0] > x->cm2->NroCols || n[1] > x->cm2->NroCols){
					post("cm_trans: the cm doesn't have the number of column requested");
					return;
				}
				InterCols(x->cm2,n[0],n[1]);
			}
		}
		/*Swapping*/
		if(strcmp(sy->s_name, "SWAP") == 0) { 
			x->n=0.;
			if(argc==0){ /*perform all the possible swapping operations but outputs just the final result*/
				if(Swap(x->cm2)==FALSE) {
					post("cm_trans: could not reduce the position density of this cm");
					return;
				}
			}
			if(argc == 1) {/*perform the requested number of swapping operations and outputs all the results*/ 
				temp = atom_getsymbol(&argv[0]);/*get the maximal number of swapping operations, if any*/
				if(strcmp(temp->s_name, "float") == 0){
					x->n= (float)atom_getfloat(&argv[0]); 
				}  
				for(h = 0; h < 2; h++){
					if(h && flag==FALSE) tipo = TRUE;
					for(z = 0; z < x->cm2->NroFilas; z++){
						for(w = 0; w < NEXTC * x->cm2->NroCols; w++){
							if(x->cm2->mat[w][z] != SPAC && x->cm2->mat[w][z] != ETY){
								for(j = 0; j < x->cm2->NroFilas; j++){
									for(i = 0; i < NEXTC * x->cm2->NroCols; i++){
										if(x->cm2->mat[i][j] != SPAC && x->cm2->mat[i][j] != ETY){
											if(i != w && j != z){
												if(x->cm2->mat[i][j] == x->cm2->mat[w][z]){
													Densidad(x->cm2, dens);
													c = (t_int)(w/NEXTC); 
													d = (t_int)(i/NEXTC);
													if(((dens[c][j] + tipo) < dens[c][z]) && ((dens[d][z] + tipo) < dens[d][j])){
														flag = TRUE;
														
														Insertar(x->cm2, j, c, x->cm2->mat[i][j]);
														Borrar(x->cm2, z, c,  x->cm2->mat[i][j]);
														Insertar(x->cm2, z, d, x->cm2->mat[i][j]);
														Borrar(x->cm2, j, d,  x->cm2->mat[i][j]);
														
														sprintf(s, "%p",x->cm2);
														temp_symbol = gensym(s);
														temps=gensym(MMID); /*ident*/
														SETSYMBOL(&(clist[0]),temps);
														SETSYMBOL(&(clist[1]),temp_symbol);
														if(nop++ < (t_int)x->n)
															outlet_list (x->cm_out, gensym("list"),2,clist);
														else
															break;
													}
												}
											}
										}
									}
								}
							}
						}
					}
				}
				if(flag==FALSE) {
					post("cm_trans: could not reduce the position density of this cm");
					return; 
				}
				else
					return;
			}
			if(argc == 4) {/*swap two specific positions of a CM without density checking*/ 
				for(i=0; i<2; ++i) {
					temp = atom_getsymbol(&argv[i*2]);
					if(strcmp(temp->s_name, "float") == 0){
						x->row[i]= (t_int)atom_getfloat(&argv[i*2]); 
					}
					temp = atom_getsymbol(&argv[i*2+1]);
					if(strcmp(temp->s_name, "float") == 0){
						x->col[i]= (t_int)atom_getfloat(&argv[i*2+1]); 
					}
					if(x->row[i] > x->cm2->NroFilas-1 || x->col[i] > x->cm2->NroCols-1) {
						post("cm_trans: out of range Row and/or Column number, no action taken");
						return; 
					}
				}
				pos_to_pcs(x->cm2, &p1, x->row[0], x->col[0]);
				pos_to_pcs(x->cm2, &p2, x->row[1], x->col[1]);
				find_intersec(&p1, &p2,&target);
				if(target.find[0]==EOC) {
					post("cm_trans: can't swap positions, no common set betweem them");
					return;
				}
				for(i=0; i<PCSL; ++i) {
					if(target.find[i]==EOC) break;
					Borrar(x->cm2, x->row[0], x->col[0], target.find[i]);
					Insertar(x->cm2, x->row[1], x->col[0], target.find[i]);
					Borrar(x->cm2, x->row[1], x->col[1], target.find[i]);
					Insertar(x->cm2, x->row[0], x->col[1], target.find[i]);
				}
			}
		} /*swap operations end here*/
		
		
		
		/*Erasing, Writing or Adding PCS to a specific position*/
		if(strcmp(sy->s_name, "DEL") == 0 || strcmp(sy->s_name, "WRI") == 0 || strcmp(sy->s_name, "ADD") == 0 ) { 
			/*first, get the row and col of the position to erase*/ 
			if(argc >= 2) {/*first get row and col of the position to erase*/ 
				temp = atom_getsymbol(&argv[0]);
				if(strcmp(temp->s_name, "float") == 0){
					x->row[0]= (t_int)atom_getfloat(&argv[0]); 
				}
				temp = atom_getsymbol(&argv[1]);
				if(strcmp(temp->s_name, "float") == 0){
					x->col[0]= (t_int)atom_getfloat(&argv[1]); 
				}
				if(x->row[0] > x->cm2->NroFilas || x->col[0] > x->cm2->NroCols) {
					post("cm_trans: out of range Row and/or Column number, no action taken");
					return; 
				}
				/*now perform the requested operation*/
				if(strcmp(sy->s_name, "DEL") == 0 ) {
					empty_pos(x->cm2, x->row[0], x->col[0]);
				}
				if(strcmp(sy->s_name, "WRI") == 0 ) {
					if(x->pcs->find[0]==EOC){
						post("cm_trans: no PCS delivered to write, no action taken");
						return;
					}
					empty_pos(x->cm2, x->row[0], x->col[0]);
					pcs_to_pos(x->cm2, x->pcs, x->row[0], x->col[0]);
				}
				if(strcmp(sy->s_name, "ADD") == 0 ) {
					if(x->pcs->find[0]==EOC){
						post("cm_trans: no PCS delivered to add, no action taken");
						return;
					}
					for(i=0; i<PCSL; ++i) {
						if(x->pcs->find[i]==EOC) break;
						if(x->pcs->find[i]!=EOP) {
							Insertar(x->cm2, x->row[0], x->col[0],x->pcs->find[i]);
						}
					}
				}
				
			}
			else {
				post("cm_trans: need two floats (row, column) in order to define the position to erase");
				return; 
			}
		} /*erasing ends here*/
		if(strcmp(sy->s_name, "RW") == 0 || strcmp(sy->s_name, "CW") == 0) {
			if(x->pcs->find[0]==EOC) {
				post("cm_trans: no PCS pointer or NULL set received, nothing to write");
				return;
			}
			if(argc < 1) {
				post("cm_trans: need one float indicating the number of row or column to write on");
				return;
			}

			
			
		}
		
		/*transformation performed*/
		/*convert pointer to CM struct into a symbol*/
		sprintf(s, "%p",x->cm2);
		temp_symbol = gensym(s);
		temps=gensym(MMID); /*ident*/
		
		SETSYMBOL(&(clist[0]),temps);
		SETSYMBOL(&(clist[1]),temp_symbol);
		outlet_list (x->cm_out, gensym("list"),2,clist);
		return;
  }/*valid options ends here*/
  
  post("cm_trans: invalid option/s"); /*no valid options requested*/
  return;		
}

/******************************************/
void *cm_trans_new()
{
	t_cm_trans *x = (t_cm_trans *)pd_new(cm_trans_class);
	x->cm1=NULL;
	x->cm2=NULL;
	x->pcs=NULL;
	
	x->cm1=(CM*)malloc(sizeof(CM));
	x->cm2=(CM*)malloc(sizeof(CM));
	Inicializar(x->cm1);
	Inicializar(x->cm2);
	x->cmnew=FALSE;
	
	x->pcs=(PCS*)malloc(sizeof(PCS));
	x->pcs->find[0]=EOC;
	
	x->n=0.; /*transposition factor initialized to 0.*/
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("symbol"),gensym("cm_trans_get_cm"));
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("symbol"),gensym("cm_trans_get_pcs"));
	
	x->cm_out=outlet_new(&x->x_obj, &s_symbol);
	
	return (void *)x;
}
/******************************************/
void cm_trans_setup(void) {
	cm_trans_class = class_new(gensym("cm_trans"),
		(t_newmethod)cm_trans_new,
		0, sizeof(t_cm_trans),
		CLASS_DEFAULT,A_DEFFLOAT,0);
	
	class_addmethod(cm_trans_class,(t_method)cm_trans_get_cm, gensym("cm_trans_get_cm"),A_GIMME,0);
	class_addmethod(cm_trans_class,(t_method)cm_trans_get_pcs,gensym("cm_trans_get_pcs"),A_GIMME,0);
	class_addanything(cm_trans_class, cm_trans_any);	
}
/******************************************/
void cm_trans_get_cm(t_cm_trans *x, t_symbol *s, t_int argc, t_atom *argv) {
	t_symbol *temp;
	CM *tempcm;
	
	if(check_ptr_mess(argc,argv,MMID)==FALSE){
		post("cm_trans warning: no pointer to cm received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcm);
	CopiaMatriz(tempcm, x->cm1);
	x->cmnew=TRUE;
	
	return;
}
/******************************************/
void cm_trans_get_pcs(t_cm_trans *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_symbol *temp;
	PCS *tempcs;
	
	if(check_ptr_mess(argc,argv,MPID)==FALSE){
		post("cm_trans warning: no pointer to pcs received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcs);
	CopiaSet(tempcs, x->pcs);
	
	return;
}
/******************************************/
/******************************************/
void cm_trans_destroy(t_cm_trans *x){
	if(x->cm1 != NULL){
		free(x->cm1);
	}
	if(x->cm2 != NULL){
		free(x->cm2);
	}
	if(x->pcs != NULL){
		free(x->pcs);
	}
	return;	
}
/******************************************/
