/*cm_read object  by Oscar Pablo Di Liscia*/
static t_class *cm_read_class;
/*
The cm_read object expects a pointer to a CM struct.
The pointer must be generated using one of the cm_ objects.
The output:
outlet1: number of rows of the cm(float).
outlet2: number of cols of the cm(float).
outlet3: maximal number of pc for each position of the cm(float).
outlet4: a series of float lists each one being a row of the cm.
The output is the raw in the CM. -3 and -4 are spaces.
If you want to see a "clean" text version of the CM use
the cm_2txt object.
*/
typedef struct _cm_read{
  t_object  x_obj;
  t_atom    row_list[MAXELEM];
  CM *cm;   /*pointer to a CM struct*/
  t_outlet *row_out, *nr_out, *nc_out, *nexp_out;
} t_cm_read;

/*****************CM_READ DEFUNCS************/
void cm_read_list(t_cm_read *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_read_new();
void cm_read_setup(void);
void cm_read_destroy(t_cm_read *x);
/*****************CM_READ PROTOS*************/
/***********************************************/
void cm_read_list(t_cm_read *x, t_symbol *s, t_int argc, t_atom *argv){
  t_int i,j,cp=0,index=0;
  float tempf;
  t_atom *row_list;
  t_symbol *temps, *temp;
  void *tpcs;
  CM *tempcm;

  t_int cvec[PCSL];
  t_int Flag = TRUE;
  t_int ContElem = 0, n, counter=0;

  if(check_ptr_mess(argc,argv,MMID)==FALSE){
    post("cm_read warning: no pointer to CM received");
    return;
  }

  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcm);
  CopiaMatriz(tempcm, x->cm);

  /*output nr, nc and max elements X position first*/
  outlet_float(x->nexp_out,(t_float)(x->cm->MaxElemxPos));
  outlet_float(x->nr_out,(t_float)(x->cm->NroFilas));
  outlet_float(x->nc_out,(t_float)(x->cm->NroCols));
  
 /*output nc rows*/
  row_list=x->row_list;

  for(j = 0; j < x->cm->NroFilas; j++){
    for(i = 0; i < NEXTC * x->cm->NroCols; i++){
      tempf=(float)x->cm->mat[i][j];
      SETFLOAT(&(row_list[i]),tempf);
    }
    outlet_list (x->row_out, gensym("list"),i,x->row_list);
  }
  return;		
}
/******************************************/
void *cm_read_new()
{
  t_cm_read *x = (t_cm_read *)pd_new(cm_read_class);
  x->cm=NULL;

  x->cm=(CM*)malloc(sizeof(CM));
  Inicializar(x->cm);

  x->row_out=outlet_new(&x->x_obj, &s_float);
  x->nc_out=outlet_new(&x->x_obj, &s_float);
  x->nr_out=outlet_new(&x->x_obj, &s_float);
  x->nexp_out=outlet_new(&x->x_obj, &s_list);

  return (void *)x;
}
/******************************************/
void cm_read_setup(void) {
  cm_read_class = class_new(gensym("cm_read"),
		       (t_newmethod)cm_read_new,
		       0, sizeof(t_cm_read),
		       CLASS_DEFAULT,A_DEFFLOAT,0);

  class_addlist(cm_read_class, cm_read_list);	
}

/******************************************/
void cm_read_destroy(t_cm_read *x){

  if(x->cm != NULL){
    free(x->cm);
  }
  return;	
}
/******************************************/
