/*cm_ttog object  by Oscar Pablo Di Liscia*/
static t_class *cm_ttog_class;
/*
The cm_ttog object creates a pc to pc CM based on Groups of operators (See Morris, 1987, pp. 154-158). 

*/
typedef struct _cm_ttog{
	t_object  x_obj;
	PCS *pcs; /*pointer to PCS struct*/
	CM  *cm;   /*pointer to a CM struct*/
	TTOG *ttog;
	t_outlet *cm_out;
	t_outlet *cm_nrc; /*output for number of row and cols*/
} t_cm_ttog;
/*****************cm_ttog DEFUNCS************/
void cm_ttog_any(t_cm_ttog *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_ttog_new();
void cm_ttog_setup(void);
void cm_ttog_get_norm(t_cm_ttog *x, t_symbol *s, t_int argc, t_atom *argv);
void cm_ttog_get_ttog(t_cm_ttog *x, t_symbol *s, t_int argc, t_atom *argv);
void cm_ttog_destroy(t_cm_ttog *x);
/*****************cm_ttog PROTOS*************/
/***********************************************/
void cm_ttog_any(t_cm_ttog *x, t_symbol *s, t_int argc, t_atom *argv){
	 
	t_symbol *temp_symbol, *temp;
	t_symbol *temps;
	t_atom plist[2];
	t_int i, j;
	char pstr[STRLP];
	
	if(x->pcs->find[0]==EOC || x->ttog->op[0]==EOC) {
		post("cm_ttog: pointer to PCS or TTO GROUP not received, no action taken");
		return;
	}
	else{
		if(x->pcs->ncar != x->ttog->or) {
			post("cm_ttog= error, the cardinal of the PCS and the Order of the TTO Group must match, no action taken");
			return;
		}
	}

	
	if(cm_ttog(x->cm, x->ttog, x->pcs)== true) {
		
		/*convert pointer to CM struct into a symbol*/
		sprintf(pstr, "%p", x->cm);
		temp_symbol = gensym(pstr);
		temps=gensym(MMID); /*ident*/
		/*output Number of rows and cols*/
		outlet_float(x->cm_nrc,(float)x->cm->NroFilas);
		/*output a cm struct pointer*/
		SETSYMBOL(&(plist[0]),temps);
		SETSYMBOL(&(plist[1]),temp_symbol);
		outlet_list (x->cm_out, gensym("list"),2,plist);
	}
	else {
		post("cm_ttog: sorry, could not make the CM, not yet implemented");
	}
	
	return;		
}
/******************************************/
void *cm_ttog_new()
{
	t_cm_ttog *x = (t_cm_ttog *)pd_new(cm_ttog_class);
	t_int i;
	
	x->pcs=NULL;
	
	x->pcs=(PCS*)malloc(sizeof(PCS));
	x->pcs->find[0]=EOC;
	
	x->cm=(CM*)malloc(sizeof(CM));
	Inicializar(x->cm);

	x->ttog=(TTOG*)malloc(sizeof(TTOG));
	ttog_init(x->ttog);

	x->cm_out=outlet_new(&x->x_obj, &s_list);
	x->cm_nrc=outlet_new(&x->x_obj, &s_float);
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("cm_ttog_get_norm"));
	inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("cm_ttog_get_ttog"));

	return (void *)x;
}
/******************************************/
void cm_ttog_setup(void) {
	cm_ttog_class = class_new(gensym("cm_ttog"),
		(t_newmethod)cm_ttog_new,
		0, sizeof(t_cm_ttog),
		CLASS_DEFAULT,A_DEFFLOAT,0);
	class_addanything(cm_ttog_class, cm_ttog_any);
	class_addmethod(cm_ttog_class,(t_method)cm_ttog_get_norm,gensym("cm_ttog_get_norm"),A_GIMME,0);
	class_addmethod(cm_ttog_class,(t_method)cm_ttog_get_ttog,gensym("cm_ttog_get_ttog"),A_GIMME,0);
}
/******************************************/
void cm_ttog_get_norm(t_cm_ttog *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_symbol *temp;
	PCS *tempcs;
	
	if(check_ptr_mess(argc,argv,MPID)==FALSE){
		post("pcs_ttog warning: no pointer to pcs received");
		return;
	}
	temp = atom_getsymbol(&argv[1]);
	/*get the pointer to a PCS struct*/
	sscanf(temp->s_name, "%p", &tempcs);
	CopiaSet(tempcs, x->pcs);

	if(x->pcs->ncar !=3 && x->pcs->ncar !=4 && x->pcs->ncar !=6) {
		post("pcs_ttog error: allowed cardinality for PCS are only 3, 4 or 6");
		x->pcs->find[0]=EOC;
	}
	return;
}
/******************************************/
void cm_ttog_get_ttog(t_cm_ttog *x, t_symbol *s, t_int argc, t_atom *argv)
{
	t_symbol *temp;
	t_int i, j, nm;
	
	temp = atom_getsymbol(&argv[0]);
    if(strcmp(temp->s_name, "float") == 0){
		x->ttog->ty =(t_int)atom_getfloat(&argv[0]);
	}
	temp = atom_getsymbol(&argv[1]);
    if(strcmp(temp->s_name, "float") == 0){
		x->ttog->cl =(t_int)atom_getfloat(&argv[1]);
	}
	
	if(argc >=3) {
		temp = atom_getsymbol(&argv[2]);
		if(strcmp(temp->s_name, "float") == 0){
			x->ttog->mb =(t_int)atom_getfloat(&argv[2]);
		}
		
	}
	else {
		x->ttog->mb=1;
	}
	
	if(ttog_read_group (x->ttog)==false) {
		post("cm_ttog= error, invalid group type, class or member");
		ttog_init(x->ttog);
		return;
	}

	return;
}

/******************************************/
void cm_ttog_destroy(t_cm_ttog *x){
	
	if(x->pcs != NULL){
		free(x->pcs);
	}
	
	if(x->cm != NULL){
		free(x->cm);
	}

	if(x->ttog != NULL){
		free(x->ttog);
	}

	return;	
}
/******************************************/
