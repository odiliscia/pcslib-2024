/*cm_t1b object  by Oscar Pablo Di Liscia*/
static t_class *cm_t1b_class;
/*
The cm_t1b object expects a pointer to a PCS struct.
The output is a pointer to a CM struct. To access the data, a cm_read
object must be used.
*/
typedef struct _cm_t1b{
  t_object  x_obj;
  PCS *pcs;		  /*pointer to PCS struct*/
  CM  *cm;
  t_outlet  *cm_out, *cm_nrc;
} t_cm_t1b;
/*****************CM_T1B DEFUNCS************/
void cm_t1b_any(t_cm_t1b *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_t1b_new();
void cm_t1b_setup(void);
void cm_t1b_destroy(t_cm_t1b *x);
/*****************CM_T1B PROTOS*************/
/***********************************************/
void cm_t1b_any(t_cm_t1b *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int i; 
  t_symbol *temp_symbol;
  char pstr[STRLP]; 
  t_symbol *temps;
  t_atom plist[2];
  PCS *tempcs;

  if(check_ptr_mess(argc,argv,MPID)==FALSE){
    post("cm_t1b: no pointer to pcs received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcs);
  CopiaSet(tempcs, x->pcs);

  /*Build the cm*/
  MatTipo1b(x->cm, x->pcs);
  
  /*output Number of rows and cols*/
  SETFLOAT(&(plist[0]),(float)x->cm->NroFilas);
  SETFLOAT(&(plist[1]),(float)x->cm->NroCols);
  outlet_list(x->cm_nrc, gensym("list"),2,plist);
  /*convert pointer to CM struct into symbol*/
  sprintf(pstr, "%p", x->cm);
  temp_symbol = gensym(pstr);
  temps=gensym(MMID); /*ident*/
  /*output a cm struct pointer*/
  SETSYMBOL(&(plist[0]),temps);
  SETSYMBOL(&(plist[1]),temp_symbol);
  outlet_list (x->cm_out, gensym("list"),2,plist);

  return;		
}
/******************************************/
void *cm_t1b_new()
{
  t_cm_t1b *x = (t_cm_t1b *)pd_new(cm_t1b_class);
  x->pcs=NULL;
	
  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;
  x->cm=(CM*)malloc(sizeof(CM));
  Inicializar(x->cm);
  x->cm_out=outlet_new(&x->x_obj, &s_list);
  x->cm_nrc=outlet_new(&x->x_obj, &s_list);

  return (void *)x;
}
/******************************************/
void cm_t1b_setup(void) {
  cm_t1b_class = class_new(gensym("cm_t1b"),
		       (t_newmethod)cm_t1b_new,
		       0, sizeof(t_cm_t1b),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addlist(cm_t1b_class, cm_t1b_any);	
}
/******************************************/
void cm_t1b_destroy(t_cm_t1b *x){

  if(x->pcs != NULL){
    free(x->pcs);
  }
 if(x->cm != NULL){
    free(x->cm);
  }

  return;	
}
/******************************************/
