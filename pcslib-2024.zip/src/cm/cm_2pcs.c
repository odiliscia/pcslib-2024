/*cm_2pcs object by Oscar Pablo Di Liscia*/
static t_class *cm_2pcs_class;
/*
The cm_2pcs object expects a pointer to a CM struct in its right inlet.
The pointer must be generated using one of the cm objects.
It then scan the CM and create a PCS according the following data which
must be delivered to it hot inlet:
1-POS(symbol) r(float) c(float): get the PCS at position r(row) c(col).
2-ROW(symbol) r(float): get the PCS with all the PCs in the positions of r(row).
3-COL(symbol) c(float): get the PCS with all the PCs in the positions of c(col).
4-ALL: get the PCS with the all the PCs in the CM.
The output is a PCS pointer.
If no PCs are found, no action is taken.
*/

typedef struct _cm_2pcs{
  t_object  x_obj;
  CM *cm;   /*pointer to a CM struct*/
  PCS *pcs;
  t_int c;
  t_int r;
  t_outlet *pcs_out;
} t_cm_2pcs;

/*****************CM_2PCS DEFUNCS************/
void cm_2pcs_any(t_cm_2pcs *x, t_symbol *s, t_int argc, t_atom *argv);
void *cm_2pcs_new();
void cm_2pcs_setup(void);
void cm_get(t_cm_2pcs *x, t_symbol *s, t_int argc, t_atom *argv);
void cm_2pcs_destroy(t_cm_2pcs *x);
/*****************CM_2PCS PROTOS*************/
/***********************************************/
void cm_2pcs_any(t_cm_2pcs *x, t_symbol *s, t_int argc, t_atom *argv){
  t_symbol *temp;
  t_int i,j,offset;
  t_symbol *temp_symbol;
  char str[STRLP];
  t_symbol *temps; 
  t_atom plist[2];

  /*LOOK FOR VALID OPTIONS*/
  if(strcmp(s->s_name, "POS") == 0 || strcmp(s->s_name, "ROW") == 0 || strcmp(s->s_name, "COL") == 0 || strcmp(s->s_name, "ALL") == 0) {
 
    /*position requested*/
    if(strcmp(s->s_name, "POS") == 0) {
      if(argc =! 2) {
	post("cm_2pcs warning: need a row and column number");
	return;
      }
      temp = atom_getsymbol(&argv[0]);
      if(strcmp(temp->s_name, "float") == 0){
	x->r= (t_int)atom_getfloat(&argv[0]);
      }
      temp = atom_getsymbol(&argv[1]);
      if(strcmp(temp->s_name, "float") == 0){
	x->c= (t_int)atom_getfloat(&argv[1]);
      }
      if(check_rc(x->cm, x->r,x->c)==FALSE){
	post("cm_2pcs warning: out of range row/column");
	return;
      }
      x->pcs->find[0]=EOC;
      pos_to_pcs(x->cm, x->pcs, x->r,x->c);
    }
    /*row requested*/
    if(strcmp(s->s_name, "ROW") == 0) {
      if(argc =! 1) {
	post("cm_2pcs warning: need a row number");
	return;
      }
      temp = atom_getsymbol(&argv[0]);
      if(strcmp(temp->s_name, "float") == 0){
	x->r= (t_int)atom_getfloat(&argv[0]);
      }
      if(x->r < 0 || x->r > x->cm->NroFilas-1){
	post("cm_2pcs warning: out of range row");
	return;
      }
      row_to_pcs(x->cm, x->pcs, x->r);
    }
    /*column requested*/
    if(strcmp(s->s_name, "COL") == 0) {
      if(argc =! 1) {
	post("cm_2pcs warning: need a column number");
	return;
      }
      temp = atom_getsymbol(&argv[0]);
      if(strcmp(temp->s_name, "float") == 0){
	x->c= (t_int)atom_getfloat(&argv[0]);
      }
      if(x->c < 0 || x->c > x->cm->NroCols-1){
	post("cm_2pcs warning: out of range column");
	return;
      }
      col_to_pcs(x->cm, x->pcs, x->c);
    }
    /*all the cm requested*/
    if(strcmp(s->s_name, "ALL") == 0) {
      cm_to_pcs(x->cm, x->pcs);
    }
    /*now send data*/
    /*convert pointer to PCS struct into symbol*/
    sprintf(str, "%p",x->pcs);
    temp_symbol = gensym(str);
    temps=gensym(MPID); /*ident*/
    SETSYMBOL(&(plist[0]),temps);
    SETSYMBOL(&(plist[1]),temp_symbol);
    //if(x->pcs->find[0]!=EOC){ //PCS may be a NULL set
      outlet_list (x->pcs_out, gensym("list"),2,plist);
      x->pcs->find[0]=EOC;
    //}
    return;
  }/*valid options ends here*/

  post("cm_2pcs: no valid options");
  return;		
}
/******************************************/
void *cm_2pcs_new()
{
  t_cm_2pcs *x = (t_cm_2pcs *)pd_new(cm_2pcs_class);
  x->cm=NULL;

  x->pcs=(PCS*)malloc(sizeof(PCS));
  x->pcs->find[0]=EOC;

  x->cm=(CM*)malloc(sizeof(CM));
  Inicializar(x->cm);

  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("float"),gensym("cm_get"));
  x->pcs_out=outlet_new(&x->x_obj, &s_symbol);

  return (void *)x;
}
/******************************************/
void cm_2pcs_setup(void) {
  cm_2pcs_class = class_new(gensym("cm_2pcs"),
		       (t_newmethod)cm_2pcs_new,
		       0, sizeof(t_cm_2pcs),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addmethod(cm_2pcs_class,(t_method)cm_get,gensym("cm_get"),A_GIMME,0);
  class_addanything(cm_2pcs_class, cm_2pcs_any);	
}
/******************************************/
void cm_get(t_cm_2pcs *x, t_symbol *s, t_int argc, t_atom *argv) {
  t_symbol *temp;
  CM *tempcm;
  
  if(check_ptr_mess(argc,argv,MMID)==FALSE){
    post("cm_trans warning: no pointer to cm received");
    return;
  }
  temp = atom_getsymbol(&argv[1]);
  /*get the pointer to a PCS struct*/
  sscanf(temp->s_name, "%p", &tempcm);
  CopiaMatriz(tempcm, x->cm);

  return;
}
/******************************************/
void cm_2pcs_destroy(t_cm_2pcs *x){

  if(x->cm != NULL){
    free(x->cm);
  }
  if(x->pcs != NULL){
    free(x->pcs);
  }

  return;	
}
/******************************************/
