
/*
t_int tto_pc(t_int pc, t_int n, t_int tto);
t_int ttog_read_group (TTOG *ttog);
t_int ttog_read_member(TTOG *ttog, t_int offset);
void ttog_init(TTOG *ttog);
void ttog_perform(TTOG *ttog, t_int *pcsv, t_int **mat);
void ttog_perform_on_mat(TTOG *ttog, t_int **mat);
t_int pc_ttog_ind(TTOG *ttog, t_int indx, t_int pc);
*/
/*****************perform a TTO on a PC*****************/
t_int tto_pc(t_int pc, t_int n, t_int tto)
{
	if(tto==TO) {
		pc=(pc+n)%12;
		return(pc);
	}
	if(tto==IO) {
		pc=((12-pc)+n)%12;
		return(pc);
	}
	if(tto==MO) {
		pc=(pc*5+n)%12;
		return(pc);
	}
	if(tto==MIO) {
		pc=(pc*7+n)%12;
		return(pc);
	}
	return(-1);
}
/*****************read a group member*******************/
t_int ttog_read_member(TTOG *ttog, t_int offset) 
{
	t_int i,j=0;
	
	for(i=offset; i < offset+ttog->or; ++i) {
		ttog->op[j++]=goptr[i];
	}
	
	return(true);
}
/***************************************************/
t_int ttog_read_group (TTOG *ttog) {
	t_int aux, offset=0,i;
	t_int nc [5]={NCT1,NCT2,NCT3,NCT4,NCT5};
	t_int off[5]={T1B,T2B,T3B,T4B,T5B};
	
	
	if(ttog->ty < 1 || ttog->ty > 5 ) 
	{return(false);}
	
	offset=off[(ttog->ty)-1];
	ttog->or=goptr[offset+1];
	
	if(ttog->cl < 1 || ttog->cl > nc[(ttog->ty)-1] )
	{return(false);}
	
	/*locate group on table*/
	for(i=0; i<(ttog->cl)-1; ++i) {
		offset+=(goptr[offset+1]*goptr[offset+2])+3;
	}
	/*group order*/
	ttog->or=goptr[offset+1];
	
	if(ttog->mb < 1 || ttog->mb > goptr[offset+2] )
	{return(false);}
	
	offset+=((ttog->mb-1)*ttog->or)+3;
	ttog_read_member(ttog,offset);
	
	return(true);
}
/************************************************************/
void ttog_init(TTOG *ttog)
{
	t_int i;
	
	for(i=0; i<MAX_ORDER; ++i) {
		ttog->op[i]=0;
	}
	ttog->op[i]=EOC;
	ttog->ty=ttog->cl=ttog->mb=ttog->or=0;
	
	return;
}
/************************************************************/
void ttog_perform(TTOG *ttog, t_int *pcsv, t_int **mat)
{
	t_int i, j , x, step=0;
	
	
	/*Only T operator groups*/
	if(ttog->ty == 1) {
		for(i=0; i<ttog->or; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=(pcsv[j]+ttog->op[i])%12;
			}
		}
	}  
	/* 0o0 1o3 2o1 3o4 4o2 5o5    o0 o1 o2 o3 o4 o5*/
	/*IT, MT or IMT operators groups*/
	if(ttog->ty == 2 || ttog->ty == 3 || ttog->ty == 4) {
		for(i=0; i<ttog->or/2; ++i) {			
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=(pcsv[j]+ttog->op[i])%12;
			}
		}
		for(i=ttog->or/2; i<ttog->or; ++i) {			
			for(j=0; j<ttog->or; ++j) {
				if(ttog->ty==2) {
					mat[i][j]=((12-pcsv[j])+ttog->op[i])%12;
				}
				if(ttog->ty==3) {
					mat[i][j]=((5*pcsv[j])+ttog->op[i])%12;
				}
				
				if(ttog->ty==4) {
					mat[i][j]=((7*pcsv[j])+ttog->op[i])%12;
				}
			}
		}
		
	}
	
	/*T/IT/MT/MI operators groups*/
	if(ttog->ty == 5) {
		step=ttog->or/4;
		for(i=0; i<step; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=(pcsv[j]+ttog->op[i])%12;
			}		
		}
		for(i=step; i<step+step; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=((12-pcsv[j])+ttog->op[i])%12;
			}		
		}
		for(i=step*2; i<step*3; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=((5*pcsv[j])+ttog->op[i])%12;
			}		
		}
		for(i=step*3; i<step*4; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=((7*pcsv[j])+ttog->op[i])%12;
			}		
		}
	}
	return;
}
/************************************************************/
void ttog_perform_on_mat(TTOG *ttog, t_int **mat)
{
	t_int i, j , x, step=0;
	
	
	/*Only T operator groups*/
	if(ttog->ty == 1) {
		for(i=0; i<ttog->or; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]= (mat[i][j]+ttog->op[i])%12;
			}
		}
		return;
	}
	/*IT, MT or IMT operators groups*/
	if(ttog->ty == 2 || ttog->ty == 3 || ttog->ty == 4) {
		for(i=0; i<ttog->or/2; ++i) {			
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=(mat[i][j]+ttog->op[i])%12;
			}
		}
		for(i=ttog->or/2; i<ttog->or; ++i) {			
			for(j=0; j<ttog->or; ++j) {
				if(ttog->ty==2) {
					mat[i][j]=((12-mat[i][j])+ttog->op[i])%12;
				}
				if(ttog->ty==3) {
					mat[i][j]=((5*mat[i][j])+ttog->op[i])%12;
				}
				
				if(ttog->ty==4) {
					mat[i][j]=((7*mat[i][j])+ttog->op[i])%12;
				}
			}
		}
		return;
	}
	
	/*T/IT/MT/MI operators groups*/
	if(ttog->ty == 5) {
		step=ttog->or/4;
		for(i=0; i<step; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=(mat[i][j]+ttog->op[i])%12;
			}		
		}
		for(i=step; i<step*2; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=((12-mat[i][j])+ttog->op[i])%12;
			}		
		}
		for(i=step*2; i<step*3; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=((5*mat[i][j])+ttog->op[i])%12;
			}		
		}
		for(i=step*3; i<step*4; ++i) {
			for(j=0; j<ttog->or; ++j) {
				mat[i][j]=((7*mat[i][j])+ttog->op[i])%12;
			}
		}
		return;
	}
	return;
}
/*searchs a TTO by its index in a given group  and perform it on a given PC*/
/************************************************************/
t_int pc_ttog_ind(TTOG *ttog, t_int indx, t_int pc)
{
t_int mult, step;
	
	if(ttog->ty==1) {
		pc=(pc+ttog->op[indx])%12;
		return(pc);
	}
	if(ttog->ty == 2 || ttog->ty == 3 || ttog->ty == 4 ) {
		if(indx < ttog->or/2) {
			pc=(pc+ttog->op[indx])%12;
			return(pc);
		}
		else {
			if(ttog->ty==2) {
				pc=((12-pc)+ttog->op[indx])%12;
				return(pc);
			}
			mult=(ttog->ty==3? 5:7);
			pc=(mult*pc + ttog->op[indx])%12;
			return(pc);
		}
	}
	
	step=ttog->or/4;
	if(indx < step) {
		pc=(pc+ttog->op[indx])%12;
		return(pc);
	}
	if(indx >= step && indx < step*2) {
		pc=pc=((12-pc)+ttog->op[indx])%12;
		return(pc);
	}
	if(indx >= step*2 && indx < step*3) {
		pc=(5*pc + ttog->op[indx])%12;
		return(pc);
	}
	if(indx >= step*3 && indx < step*4) {
		pc=(7*pc + ttog->op[indx])%12;
		return(pc);
	}

return(-1); /*something wrong happened*/
}