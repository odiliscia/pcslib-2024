/*rho object  by Oscar Pablo Di Liscia*/
static t_class *rho_class;
/*
The rho object expects two lists of equal size. The lists are supposed
to have ints which may represent either a pitch histogram (size 12 in
this case), ICVs (size 6 in this case) or an IC succesion (any size).
It computes Spearman�s RHO correlation coefficient on the two lists.
The output is a float with the value of the coefficient.
*/
typedef struct _rho{
  t_object  x_obj;
  float *l1, *l2;
  float rho;
  t_int n1;
  t_int n2;
  t_outlet  *rho_out;
} t_rho;
/*****************rho DEFUNCS************/
void rho_any(t_rho *x, t_symbol *s, t_int argc, t_atom *argv);
void *rho_new();
void rho_setup(void);
void rho_getl1(t_rho *x, t_symbol *s, t_int argc, t_atom *argv);
void rho_getl2(t_rho *x, t_symbol *s, t_int argc, t_atom *argv);
void rho_destroy(t_rho *x);
/*****************rho PROTOS*************/
/***********************************************/
void rho_any(t_rho *x, t_symbol *s, t_int argc, t_atom *argv){

	t_int i;

	if(x->n1 == 0 || x->n2==0) {
		post("rho: one or two input lists missing, no action taken");
		return;
	}
	if(x->n1 != x->n2) {
		post("rho: the number of elements of the two lists must match, no action taken");
		return;
	}

	x->rho=rho_calc(x->n1,x->l1,x->l2);
	outlet_float(x->rho_out,x->rho);

  return;		
}
/******************************************/
void *rho_new()
{
  t_rho *x = (t_rho *)pd_new(rho_class);
	
  x->l1=(float*)malloc(sizeof(float));
  x->l2=(float*)malloc(sizeof(float));
  x->n1=0;
  x->n2=0;

  x->rho_out=outlet_new(&x->x_obj, &s_symbol);
  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("rho_getl1"));
  inlet_new(&x->x_obj,&x->x_obj.ob_pd,gensym("list"),gensym("rho_getl2"));

  return (void *)x;
}
/******************************************/
void rho_setup(void) {
  rho_class = class_new(gensym("rho"),
		       (t_newmethod)rho_new,
		       0, sizeof(t_rho),
		       CLASS_DEFAULT,A_DEFFLOAT,0);
  class_addanything(rho_class, rho_any);
  class_addmethod(rho_class,(t_method)rho_getl1,gensym("rho_getl1"),A_GIMME,0);
  class_addmethod(rho_class,(t_method)rho_getl2,gensym("rho_getl2"),A_GIMME,0);
}
/******************************************/
void rho_getl1(t_rho *x, t_symbol *s, t_int argc, t_atom *argv){
	
	t_int i;
	t_symbol *temp;

	for(i = 0; i < argc; i++){
		temp = atom_getsymbol(&argv[i]);
		if(strcmp(temp->s_name, "float") == 0){
			x->l1[i] =(t_int)atom_getfloat(&argv[i]);
			x->l1=(float*)realloc(x->l1,sizeof(float)*(i+2));
		}
	}
	x->n1=argc;

	return;
}
/******************************************/
void rho_getl2(t_rho *x, t_symbol *s, t_int argc, t_atom *argv){
	
	t_int i;
	t_symbol *temp;

	for(i = 0; i < argc; i++){
		temp = atom_getsymbol(&argv[i]);
		if(strcmp(temp->s_name, "float") == 0){
			x->l2[i] =(t_int)atom_getfloat(&argv[i]);
			x->l2=(float*)realloc(x->l2,sizeof(float)*(i+2));
		}
	}
	x->n2=argc;

	return;
}
/******************************************/
void rho_destroy(t_rho *x){

  if(x->l1 != NULL){
    free(x->l1);
  }
 if(x->l2 != NULL){
    free(x->l2);
  }

  return;	
}
/******************************************/
